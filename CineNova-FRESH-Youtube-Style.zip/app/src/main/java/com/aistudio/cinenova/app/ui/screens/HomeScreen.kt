package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.model.Movie
import com.aistudio.cinenova.app.data.model.ShortVideo
import com.aistudio.cinenova.app.data.model.WatchHistoryItem
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.components.MovieCard
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  onMovieClick: (String) -> Unit,
  onPlayClick: (String) -> Unit,
  onShortsClick: () -> Unit
) {
  val scope = rememberCoroutineScope()
  val movies by repository.movies.collectAsState()
  val shorts by repository.shorts.collectAsState()
  val watchHistory by repository.watchHistory.collectAsState()
  val watchlist by repository.watchlist.collectAsState()

  var selectedCategory by remember { mutableStateOf("All") }

  val featuredMovie = remember(movies) { movies.firstOrNull() }
  val filteredMovies = remember(movies, selectedCategory) {
    if (selectedCategory == "All") movies else movies.filter { it.category.equals(selectedCategory, ignoreCase = true) }
  }
  val latestMovies = remember(movies) { movies.sortedByDescending { it.createdAt } }
  val popularMovies = remember(movies) { movies.sortedByDescending { it.views } }
  val recommendedMovies = remember(movies) { movies.sortedByDescending { it.rating } }

  val isFeaturedInWatchlist = remember(featuredMovie, watchlist) {
    featuredMovie?.let { repository.isInWatchlist(it.movieId) } ?: false
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .testTag("home_screen_content"),
    contentPadding = PaddingValues(bottom = 90.dp)
  ) {
    // Featured Hero Banner
    if (featuredMovie != null) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(380.dp)
            .testTag("featured_banner")
        ) {
          // Backdrop Image
          AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
              .data(featuredMovie.backdrop.ifEmpty { featuredMovie.poster })
              .crossfade(true)
              .build(),
            contentDescription = featuredMovie.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )

          // Dramatic Gradient Overlays (Top, Bottom, Sides)
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    CineDarkBackground.copy(alpha = 0.5f),
                    Color.Transparent,
                    CineDarkBackground.copy(alpha = 0.7f),
                    CineDarkBackground
                  ),
                  startY = 0f,
                  endY = 1100f
                )
              )
          )

          // Content info & CTA buttons
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .align(Alignment.BottomStart)
              .padding(horizontal = 16.dp, vertical = 12.dp)
          ) {
            // Category & Year Badges
            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                color = CineRed,
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = "FEATURED",
                  color = Color.White,
                  fontWeight = FontWeight.Black,
                  fontSize = 10.sp,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }

              Text(
                text = "${featuredMovie.category} • ${featuredMovie.year} • ${featuredMovie.duration}",
                color = CineTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = featuredMovie.title,
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 24.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = featuredMovie.description,
              color = CineTextSecondary,
              fontSize = 12.sp,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Button(
                onClick = { onPlayClick(featuredMovie.movieId) },
                colors = ButtonDefaults.buttonColors(containerColor = CineRed),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                  .height(42.dp)
                  .testTag("featured_watch_button")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Watch Now",
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = Color.White
                )
              }

              OutlinedButton(
                onClick = {
                  scope.launch {
                    repository.toggleWatchlist(currentUserId, featuredMovie)
                  }
                },
                colors = ButtonDefaults.outlinedButtonColors(
                  containerColor = CineDarkSurface.copy(alpha = 0.8f),
                  contentColor = Color.White
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, CineCardBorder),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.height(42.dp)
              ) {
                Icon(
                  imageVector = if (isFeaturedInWatchlist) Icons.Default.Check else Icons.Default.Add,
                  contentDescription = null,
                  tint = if (isFeaturedInWatchlist) CineGold else Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isFeaturedInWatchlist) "In Watchlist" else "Watchlist",
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 13.sp
                )
              }
            }
          }
        }
      }
    }

    // Fresh-install state: no fake/demo videos are shown.
    if (movies.isEmpty() && shorts.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 18.dp)
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              Icons.Default.VideoLibrary,
              contentDescription = null,
              tint = CineRed,
              modifier = Modifier.size(42.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "No videos yet",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 20.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "CineNova is fresh. Published uploads will appear here automatically.",
              color = CineTextSecondary,
              fontSize = 13.sp
            )
          }
        }
      }
    }

    // Categories Pill Row
    item {
      Column(modifier = Modifier.padding(top = 16.dp)) {
        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(repository.categories) { cat ->
            val isSelected = cat == selectedCategory
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = if (isSelected) CineRed else CineDarkSurface,
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSelected) CineRed else CineCardBorder
              ),
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { selectedCategory = cat }
            ) {
              Text(
                text = cat,
                color = if (isSelected) Color.White else CineTextSecondary,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
              )
            }
          }
        }
      }
    }

    // Continue Watching Section (if user has watch history)
    if (watchHistory.isNotEmpty()) {
      item {
        Column(modifier = Modifier.padding(top = 22.dp)) {
          SectionHeader(title = "Continue Watching")
          LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            items(watchHistory, key = { it.historyId }) { history ->
              ContinueWatchingCard(
                item = history,
                onPlay = { onPlayClick(history.videoId) }
              )
            }
          }
        }
      }
    }

    // CineShorts Preview Rail
    if (shorts.isNotEmpty()) {
      item {
        Column(modifier = Modifier.padding(top = 22.dp)) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = CineRed, modifier = Modifier.size(20.dp))
              Text(
                text = "CineShorts",
                color = CineTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
              )
            }

            Text(
              text = "See All",
              color = CineGoldLight,
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp,
              modifier = Modifier.clickable { onShortsClick() }
            )
          }

          LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(shorts, key = { it.shortId }) { short ->
              ShortPreviewCard(
                short = short,
                onClick = { onShortsClick() }
              )
            }
          }
        }
      }
    }

    // Latest Movies
    item {
      Column(modifier = Modifier.padding(top = 22.dp)) {
        SectionHeader(title = if (selectedCategory == "All") "Latest Releases" else "$selectedCategory Movies")
        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(if (selectedCategory == "All") latestMovies else filteredMovies, key = { it.movieId }) { movie ->
            MovieCard(
              movie = movie,
              onClick = { onMovieClick(movie.movieId) }
            )
          }
        }
      }
    }

    // Popular Movies
    item {
      Column(modifier = Modifier.padding(top = 22.dp)) {
        SectionHeader(title = "Popular on CineNova")
        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(popularMovies, key = { it.movieId }) { movie ->
            MovieCard(
              movie = movie,
              onClick = { onMovieClick(movie.movieId) }
            )
          }
        }
      }
    }

    // Recommended for You
    item {
      Column(modifier = Modifier.padding(top = 22.dp)) {
        SectionHeader(title = "Recommended For You")
        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(recommendedMovies, key = { it.movieId }) { movie ->
            MovieCard(
              movie = movie,
              onClick = { onMovieClick(movie.movieId) }
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SectionHeader(title: String) {
  Text(
    text = title,
    color = CineTextPrimary,
    fontWeight = FontWeight.Bold,
    fontSize = 18.sp,
    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
  )
}

@Composable
private fun ContinueWatchingCard(
  item: WatchHistoryItem,
  onPlay: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
    modifier = Modifier
      .width(190.dp)
      .clip(RoundedCornerShape(10.dp))
      .clickable { onPlay() }
  ) {
    Column {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(105.dp)
      ) {
        AsyncImage(
          model = item.poster,
          contentDescription = item.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Center play circle
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.65f))
            .align(Alignment.Center),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White)
        }

        // Progress bar at bottom
        LinearProgressIndicator(
          progress = { (item.progressPercentage / 100f).coerceIn(0f, 1f) },
          color = CineRed,
          trackColor = Color.Black.copy(alpha = 0.6f),
          modifier = Modifier
            .fillMaxWidth()
            .height(4.dp)
            .align(Alignment.BottomCenter)
        )
      }

      Column(modifier = Modifier.padding(8.dp)) {
        Text(
          text = item.title,
          color = CineTextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = "${item.progressPercentage}% watched",
          color = CineTextSecondary,
          fontSize = 10.sp
        )
      }
    }
  }
}

@Composable
private fun ShortPreviewCard(
  short: ShortVideo,
  onClick: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
    modifier = Modifier
      .width(110.dp)
      .height(160.dp)
      .clip(RoundedCornerShape(12.dp))
      .clickable { onClick() }
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      AsyncImage(
        model = short.thumbnail,
        contentDescription = short.title,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
      )

      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
            )
          )
      )

      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(8.dp)
      ) {
        Text(
          text = short.title,
          color = Color.White,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = "${short.views} views",
          color = CineGoldLight,
          fontSize = 9.sp
        )
      }
    }
  }
}
