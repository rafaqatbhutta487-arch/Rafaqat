-- CineNova Storage policies for existing public bucket: cinenova-videos.
-- New app uploads are stored under <auth-user-id>/<uuid>.mp4.
-- Public retrieval works because the bucket itself is PUBLIC.

drop policy if exists "CineNova authenticated uploads" on storage.objects;
drop policy if exists "CineNova users update own files" on storage.objects;
drop policy if exists "CineNova users delete own files" on storage.objects;

create policy "CineNova authenticated uploads"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'cinenova-videos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "CineNova users update own files"
on storage.objects for update to authenticated
using (
  bucket_id = 'cinenova-videos'
  and owner_id = auth.uid()::text
)
with check (
  bucket_id = 'cinenova-videos'
  and owner_id = auth.uid()::text
);

create policy "CineNova users delete own files"
on storage.objects for delete to authenticated
using (
  bucket_id = 'cinenova-videos'
  and owner_id = auth.uid()::text
);
