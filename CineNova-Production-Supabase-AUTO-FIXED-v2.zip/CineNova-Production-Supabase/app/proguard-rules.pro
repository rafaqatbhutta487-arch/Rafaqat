# CineNova uses direct REST/JSON models; no custom keep rules are required for debug builds.
