package com.cinenova.shortvideo.data

data class Session(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String?
)

data class Profile(
    val id: String,
    val username: String,
    val displayName: String,
    val avatarUrl: String,
    val bio: String,
    val followersCount: Long = 0,
    val followingCount: Long = 0
)

data class Video(
    val id: String,
    val userId: String,
    val username: String,
    val avatarUrl: String,
    val title: String,
    val description: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val durationSeconds: Int,
    val likesCount: Long,
    val commentsCount: Long,
    val viewsCount: Long,
    val createdAt: String,
    val hashtags: List<String> = emptyList()
)

data class CommentItem(
    val id: String,
    val userId: String,
    val username: String,
    val avatarUrl: String,
    val text: String,
    val createdAt: String
)

data class NotificationItem(
    val id: String,
    val type: String,
    val actorName: String,
    val actorAvatar: String,
    val message: String,
    val read: Boolean,
    val createdAt: String
)
