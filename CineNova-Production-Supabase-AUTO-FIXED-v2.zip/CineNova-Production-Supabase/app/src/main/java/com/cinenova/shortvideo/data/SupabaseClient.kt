package com.cinenova.shortvideo.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.TimeUnit

object SupabaseConfig {
    const val URL = "https://wvhhkipfbmfkvzpqoyvi.supabase.co"
    // Publishable/anon key is intentionally client-side safe. Never place a service-role key in this app.
    const val PUBLISHABLE_KEY = "sb_publishable_QHeXhDJpwEDv29GAv1vy_Q_jvBNfkvd"
    const val VIDEO_BUCKET = "cinenova-videos"
    const val REDIRECT_URI = "cinenova://auth/callback"
}

class SupabaseClient(private val context: Context) {
    private val prefs = context.getSharedPreferences("cinenova_session", Context.MODE_PRIVATE)
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.MINUTES)
        .callTimeout(20, TimeUnit.MINUTES)
        .build()

    @Volatile private var session: Session? = loadSession()

    fun currentSession(): Session? = session

    private fun baseHeaders(accessToken: String? = session?.accessToken): okhttp3.Headers.Builder = okhttp3.Headers.Builder()
        .add("apikey", SupabaseConfig.PUBLISHABLE_KEY)
        .add("Accept", "application/json")
        .apply { if (!accessToken.isNullOrBlank()) add("Authorization", "Bearer $accessToken") }

    private suspend fun requestJson(request: Request): JSONObject = withContext(Dispatchers.IO) {
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("${response.code}: ${body.take(600)}")
            if (body.isBlank()) JSONObject() else JSONObject(body)
        }
    }

    private suspend fun requestArray(request: Request): JSONArray = withContext(Dispatchers.IO) {
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("${response.code}: ${body.take(600)}")
            JSONArray(body)
        }
    }

    suspend fun signUp(email: String, password: String): Result<String> = runCatching {
        val json = JSONObject().put("email", email).put("password", password)
        val req = Request.Builder().url("${SupabaseConfig.URL}/auth/v1/signup")
            .headers(baseHeaders().build()).post(json.toString().toRequestBody("application/json".toMediaType())).build()
        val obj = requestJson(req)
        val userId = obj.optJSONObject("user")?.optString("id").orEmpty()
        if (userId.isBlank()) throw IOException("Account created. Check your email to verify the account, then sign in.")
        "Account created. Verify your email if Supabase requires confirmation."
    }

    suspend fun signIn(email: String, password: String): Result<Session> = runCatching {
        val req = Request.Builder().url("${SupabaseConfig.URL}/auth/v1/token?grant_type=password")
            .headers(baseHeaders().build())
            .post(JSONObject().put("email", email).put("password", password).toString().toRequestBody("application/json".toMediaType())).build()
        val o = requestJson(req)
        saveSession(parseSession(o))
        session!!
    }

    suspend fun resetPassword(email: String): Result<String> = runCatching {
        val req = Request.Builder().url("${SupabaseConfig.URL}/auth/v1/recover")
            .headers(baseHeaders().build())
            .post(JSONObject().put("email", email).toString().toRequestBody("application/json".toMediaType())).build()
        requestJson(req)
        "Password reset email requested."
    }

    suspend fun refresh(): Boolean = withContext(Dispatchers.IO) {
        val s = session ?: return@withContext false
        try {
            val req = Request.Builder().url("${SupabaseConfig.URL}/auth/v1/token?grant_type=refresh_token")
                .headers(baseHeaders().build())
                .post(JSONObject().put("refresh_token", s.refreshToken).toString().toRequestBody("application/json".toMediaType())).build()
            val o = requestJson(req)
            saveSession(parseSession(o))
            true
        } catch (_: Exception) { false }
    }

    fun beginGooglePkce(): PkceRequest {
        val verifierBytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val verifier = Base64.encodeToString(verifierBytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val challenge = Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val state = UUID.randomUUID().toString()
        prefs.edit().putString("pkce_verifier", verifier).putString("pkce_state", state).apply()
        val url = Uri.parse("${SupabaseConfig.URL}/auth/v1/authorize").buildUpon()
            .appendQueryParameter("provider", "google")
            .appendQueryParameter("redirect_to", SupabaseConfig.REDIRECT_URI)
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("state", state)
            .build().toString()
        return PkceRequest(url, state)
    }

    suspend fun finishGooglePkce(code: String, state: String): Result<Session> = runCatching {
        val expected = prefs.getString("pkce_state", null)
        val verifier = prefs.getString("pkce_verifier", null)
        if (expected.isNullOrBlank() || verifier.isNullOrBlank() || expected != state) throw IOException("Google sign-in security check failed. Please try again.")
        val req = Request.Builder().url("${SupabaseConfig.URL}/auth/v1/token?grant_type=pkce")
            .headers(baseHeaders().build())
            .post(JSONObject().put("auth_code", code).put("code_verifier", verifier).toString().toRequestBody("application/json".toMediaType())).build()
        val s = parseSession(requestJson(req))
        prefs.edit().remove("pkce_state").remove("pkce_verifier").apply()
        saveSession(s)
        s
    }

    suspend fun getProfile(userId: String): Profile? = runCatching {
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/profiles?id=eq.${Uri.encode(userId)}&select=*")
            .headers(baseHeaders().build()).get().build()
        val a = requestArray(req)
        if (a.length() == 0) null else parseProfile(a.getJSONObject(0))
    }.getOrNull()

    suspend fun upsertProfile(profile: Profile): Result<Unit> = runCatching {
        val body = JSONObject().put("id", profile.id).put("username", profile.username).put("display_name", profile.displayName).put("avatar_url", profile.avatarUrl).put("bio", profile.bio)
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/profiles")
            .headers(baseHeaders().add("Prefer", "resolution=merge-duplicates,return=minimal").build())
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        requestJson(req); Unit
    }

    suspend fun publishedVideos(limit: Int = 30, offset: Int = 0): List<Video> = runCatching {
        val url = "${SupabaseConfig.URL}/rest/v1/videos?status=eq.published&visibility=eq.public&order=created_at.desc&limit=$limit&offset=$offset&select=*,profiles(username,display_name,avatar_url)"
        val req = Request.Builder().url(url).headers(baseHeaders().build()).get().build()
        val a = requestArray(req)
        (0 until a.length()).map { parseVideo(a.getJSONObject(it)) }
    }.getOrElse { emptyList() }

    suspend fun searchVideos(query: String): List<Video> = runCatching {
        val encoded = Uri.encode("*${query.trim()}*")
        val url = "${SupabaseConfig.URL}/rest/v1/videos?status=eq.published&visibility=eq.public&or=(title.ilike.${encoded},description.ilike.${encoded})&order=created_at.desc&limit=30&select=*,profiles(username,display_name,avatar_url)"
        val a = requestArray(Request.Builder().url(url).headers(baseHeaders().build()).get().build())
        (0 until a.length()).map { parseVideo(a.getJSONObject(it)) }
    }.getOrElse { emptyList() }

    suspend fun searchProfiles(query: String): List<Profile> = runCatching {
        val encoded = Uri.encode("*${query.trim()}*")
        val url = "${SupabaseConfig.URL}/rest/v1/profiles?or=(username.ilike.${encoded},display_name.ilike.${encoded})&order=created_at.desc&limit=30&select=*"
        val a = requestArray(Request.Builder().url(url).headers(baseHeaders().build()).get().build())
        (0 until a.length()).map { parseProfile(a.getJSONObject(it)) }
    }.getOrElse { emptyList() }

    suspend fun myVideos(userId: String): List<Video> = runCatching {
        val url = "${SupabaseConfig.URL}/rest/v1/videos?user_id=eq.${Uri.encode(userId)}&status=neq.deleted&order=created_at.desc&select=*,profiles(username,display_name,avatar_url)"
        val a = requestArray(Request.Builder().url(url).headers(baseHeaders().build()).get().build())
        (0 until a.length()).map { parseVideo(a.getJSONObject(it)) }
    }.getOrElse { emptyList() }

    suspend fun uploadVideo(uri: Uri, title: String, description: String, hashtags: List<String>, onProgress: (Long, Long) -> Unit): Result<Video> = runCatching {
        val s = session ?: throw IOException("Please sign in first.")
        val fileName = "${s.userId}/${UUID.randomUUID()}.mp4"
        val temp = File.createTempFile("upload_", ".mp4", context.cacheDir)
        context.contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } } ?: throw IOException("Could not read selected video.")
        val total = temp.length()
        if (total <= 0L) throw IOException("Selected video is empty.")
        val body = ProgressRequestBody(temp, "video/mp4", onProgress)
        val req = Request.Builder().url("${SupabaseConfig.URL}/storage/v1/object/${SupabaseConfig.VIDEO_BUCKET}/$fileName")
            .headers(baseHeaders(s.accessToken).add("Content-Type", "video/mp4").add("x-upsert", "false").build()).post(body).build()
        withContext(Dispatchers.IO) { http.newCall(req).execute().use { r -> if (!r.isSuccessful) throw IOException("Storage upload ${r.code}: ${r.body?.string()?.take(500)}") } }
        val publicUrl = "${SupabaseConfig.URL}/storage/v1/object/public/${SupabaseConfig.VIDEO_BUCKET}/${fileName.split("/").joinToString("/") { Uri.encode(it) }}"
        val id = UUID.randomUUID().toString()
        val json = JSONObject().put("id", id).put("user_id", s.userId).put("title", title).put("description", description).put("video_url", publicUrl).put("thumbnail_url", JSONObject.NULL).put("duration_seconds", 0).put("visibility", "public").put("status", "published").put("hashtags", JSONArray(hashtags))
        val post = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/videos")
            .headers(baseHeaders(s.accessToken).add("Prefer", "return=representation").build()).post(json.toString().toRequestBody("application/json".toMediaType())).build()
        val a = requestArray(post)
        temp.delete()
        parseVideo(a.getJSONObject(0))
    }

    suspend fun recordView(videoId: String) {
        val s = session ?: return
        val body = JSONObject().put("p_video_id", videoId)
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/rpc/record_video_view")
            .headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build())
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        runCatching { requestJson(req) }
    }

    suspend fun toggleLike(videoId: String): Result<Boolean> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val check = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/likes?user_id=eq.${s.userId}&video_id=eq.${Uri.encode(videoId)}&select=id")
            .headers(baseHeaders(s.accessToken).build()).get().build()
        val existing = requestArray(check).length() > 0
        if (existing) {
            val del = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/likes?user_id=eq.${s.userId}&video_id=eq.${Uri.encode(videoId)}")
                .headers(baseHeaders(s.accessToken).build()).delete().build(); requestJson(del); false
        } else {
            val body = JSONObject().put("user_id", s.userId).put("video_id", videoId)
            val post = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/likes").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).post(body.toString().toRequestBody("application/json".toMediaType())).build(); requestJson(post); true
        }
    }

    suspend fun isLiked(videoId: String): Boolean = runCatching {
        val s = session ?: return@runCatching false
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/likes?user_id=eq.${s.userId}&video_id=eq.${Uri.encode(videoId)}&select=id").headers(baseHeaders(s.accessToken).build()).get().build()
        requestArray(req).length() > 0
    }.getOrDefault(false)

    suspend fun comments(videoId: String): List<CommentItem> = runCatching {
        val url = "${SupabaseConfig.URL}/rest/v1/comments?video_id=eq.${Uri.encode(videoId)}&order=created_at.desc&limit=50&select=*"
        val a = requestArray(Request.Builder().url(url).headers(baseHeaders().build()).get().build())
        (0 until a.length()).map { parseComment(a.getJSONObject(it)) }
    }.getOrElse { emptyList() }

    suspend fun addComment(videoId: String, text: String): Result<Unit> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val body = JSONObject().put("user_id", s.userId).put("video_id", videoId).put("text", text.trim())
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/comments").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).post(body.toString().toRequestBody("application/json".toMediaType())).build(); requestJson(req); Unit
    }

    suspend fun deleteOwnVideo(videoId: String): Result<Unit> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/videos?id=eq.${Uri.encode(videoId)}").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).patch(JSONObject().put("status", "deleted").toString().toRequestBody("application/json".toMediaType())).build(); requestJson(req); Unit
    }

    suspend fun saveVideo(videoId: String): Result<Boolean> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val check = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/saved_videos?user_id=eq.${s.userId}&video_id=eq.${Uri.encode(videoId)}&select=id").headers(baseHeaders(s.accessToken).build()).get().build()
        val exists = requestArray(check).length() > 0
        if (exists) {
            requestJson(Request.Builder().url("${SupabaseConfig.URL}/rest/v1/saved_videos?user_id=eq.${s.userId}&video_id=eq.${Uri.encode(videoId)}").headers(baseHeaders(s.accessToken).build()).delete().build()); false
        } else {
            requestJson(Request.Builder().url("${SupabaseConfig.URL}/rest/v1/saved_videos").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).post(JSONObject().put("user_id", s.userId).put("video_id", videoId).toString().toRequestBody("application/json".toMediaType())).build()); true
        }
    }

    suspend fun follow(targetUserId: String): Result<Boolean> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val check = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/follows?follower_id=eq.${s.userId}&following_id=eq.${Uri.encode(targetUserId)}&select=id").headers(baseHeaders(s.accessToken).build()).get().build()
        val exists = requestArray(check).length() > 0
        if (exists) { requestJson(Request.Builder().url("${SupabaseConfig.URL}/rest/v1/follows?follower_id=eq.${s.userId}&following_id=eq.${Uri.encode(targetUserId)}").headers(baseHeaders(s.accessToken).build()).delete().build()); false }
        else { requestJson(Request.Builder().url("${SupabaseConfig.URL}/rest/v1/follows").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).post(JSONObject().put("follower_id", s.userId).put("following_id", targetUserId).toString().toRequestBody("application/json".toMediaType())).build()); true }
    }

    suspend fun notifications(): List<NotificationItem> = runCatching {
        val s = session ?: return@runCatching emptyList()
        val url = "${SupabaseConfig.URL}/rest/v1/notifications?user_id=eq.${s.userId}&order=created_at.desc&limit=50&select=*"
        val a = requestArray(Request.Builder().url(url).headers(baseHeaders(s.accessToken).build()).get().build())
        (0 until a.length()).map { parseNotification(a.getJSONObject(it)) }
    }.getOrElse { emptyList() }

    suspend fun markNotificationsRead(): Result<Unit> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/notifications?user_id=eq.${s.userId}&read=eq.false").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).patch(JSONObject().put("read", true).toString().toRequestBody("application/json".toMediaType())).build(); requestJson(req); Unit
    }

    suspend fun reportVideo(videoId: String, reason: String): Result<Unit> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val body = JSONObject().put("reporter_id", s.userId).put("video_id", videoId).put("reason", reason)
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/reports").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).post(body.toString().toRequestBody("application/json".toMediaType())).build(); requestJson(req); Unit
    }

    suspend fun updateProfile(displayName: String, username: String, bio: String, avatarUrl: String): Result<Unit> = runCatching {
        val s = session ?: throw IOException("Please sign in.")
        val patch = JSONObject().put("display_name", displayName.trim()).put("username", username.trim()).put("bio", bio).put("avatar_url", avatarUrl)
        val req = Request.Builder().url("${SupabaseConfig.URL}/rest/v1/profiles?id=eq.${s.userId}").headers(baseHeaders(s.accessToken).add("Prefer", "return=minimal").build()).patch(patch.toString().toRequestBody("application/json".toMediaType())).build(); requestJson(req); Unit
    }

    suspend fun deleteAccount(): Result<Unit> = runCatching {
        throw IOException("Account deletion requires a protected server-side function; no service-role key is embedded in the APK. Deploy the documented Edge Function before enabling this action.")
    }

    fun signOut() { session = null; prefs.edit().clear().apply() }

    private fun parseSession(o: JSONObject): Session {
        val access = o.optString("access_token")
        val refresh = o.optString("refresh_token")
        val user = o.optJSONObject("user") ?: throw IOException("Invalid authentication response")
        if (access.isBlank() || refresh.isBlank()) throw IOException("Authentication response did not include a session. Verify your email if required.")
        return Session(access, refresh, user.optString("id"), user.optString("email"))
    }
    private fun saveSession(s: Session) { session = s; prefs.edit().putString("access", s.accessToken).putString("refresh", s.refreshToken).putString("uid", s.userId).putString("email", s.email).apply() }
    private fun loadSession(): Session? { val a=prefs.getString("access",null); val r=prefs.getString("refresh",null); val u=prefs.getString("uid",null); return if(a!=null&&r!=null&&u!=null) Session(a,r,u,prefs.getString("email",null)) else null }

    private fun parseProfile(o: JSONObject) = Profile(o.optString("id"),o.optString("username"),o.optString("display_name"),o.optString("avatar_url"),o.optString("bio"),o.optLong("followers_count"),o.optLong("following_count"))
    private fun parseVideo(o: JSONObject): Video { val p=o.optJSONObject("profiles"); return Video(o.optString("id"),o.optString("user_id"),p?.optString("username").orEmpty(),p?.optString("avatar_url").orEmpty(),o.optString("title"),o.optString("description"),o.optString("video_url"),o.optString("thumbnail_url"),o.optInt("duration_seconds"),o.optLong("likes_count"),o.optLong("comments_count"),o.optLong("views_count"),o.optString("created_at"),jsonStrings(o.optJSONArray("hashtags"))) }
    private fun parseComment(o: JSONObject) = CommentItem(o.optString("id"),o.optString("user_id"),o.optString("username"),o.optString("avatar_url"),o.optString("text"),o.optString("created_at"))
    private fun parseNotification(o: JSONObject) = NotificationItem(o.optString("id"),o.optString("type"),o.optString("actor_name"),o.optString("actor_avatar"),o.optString("message"),o.optBoolean("read"),o.optString("created_at"))
    private fun jsonStrings(a: JSONArray?): List<String> = if(a==null) emptyList() else (0 until a.length()).map { a.optString(it) }

    data class PkceRequest(val url: String, val state: String)

    private class ProgressRequestBody(private val file: File, private val contentType: String, private val listener: (Long, Long) -> Unit) : okhttp3.RequestBody() {
        override fun contentType() = contentType.toMediaType()
        override fun contentLength() = file.length()
        override fun writeTo(sink: okio.BufferedSink) {
            file.inputStream().use { input -> val buffer=ByteArray(64*1024); var sent=0L; while(true){ val n=input.read(buffer); if(n<0) break; sink.write(buffer,0,n); sent+=n; listener(sent,file.length()) } }
        }
    }
}
