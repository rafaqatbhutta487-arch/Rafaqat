Firebase is intentionally NOT used by CineNova.

This version uses Supabase as the single backend for:
- Authentication
- Google OAuth
- PostgreSQL database
- Storage
- Social features
- Notifications

Do not add a Firebase service credential to the Android APK.
