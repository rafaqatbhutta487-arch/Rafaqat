# CineNova — Production Supabase Android App

CineNova is an original Android short-video social app. It uses **Supabase as the single backend** for Auth, PostgreSQL data, Storage and social features. Firebase is intentionally not included, so there is no second database/auth system to drift out of sync.

## What is real

- Email/password authentication through Supabase Auth
- Google OAuth through Supabase Auth + PKCE
- Persistent login session
- Real PostgreSQL profiles, videos, likes, comments, follows, saves, notifications, reports and watch history schema
- Real Supabase Storage upload to `cinenova-videos`
- Permanent HTTPS video URLs
- Upload progress and retryable failures
- Vertical Media3 video playback with player release on disposal
- Pagination-ready feed query
- Search for videos and creators
- Profile editing
- Follow / unfollow
- Like / unlike
- Comments
- Save / unsave
- Report video
- Delete own video
- Inbox / notifications
- Settings and logout
- Fresh install contains no seeded users, videos, likes or comments

## Backend already prepared for this project

Supabase project URL:
`https://wvhhkipfbmfkvzpqoyvi.supabase.co`

Existing storage bucket:
`cinenova-videos`

The Android app only contains the Supabase publishable/anon client key. **Never put a service-role key in the APK.**

## 1. Supabase database

Open Supabase SQL Editor and run:

`supabase-schema.sql`

This is an upgrade-safe schema. It does not insert demo content.

If you already ran the CineNova base schema, this file adds the fields and triggers needed by this version.

## 2. Supabase Storage

Keep the existing public bucket:

`cinenova-videos`

Run `supabase-storage-policies.sql` only if the bucket policies are missing. The public bucket is used only for permanent playback URLs; uploads/updates/deletes still require authenticated Storage policies.

## 3. Google Sign-In / OAuth

Google is configured in Supabase Auth, not Firebase.

Supabase Authentication → Sign In / Providers → Google:

- Enable Google
- Client ID: use the Web OAuth client created in Google Cloud
- Client Secret: use the secret stored in Supabase
- Skip nonce checks: OFF
- Allow users without an email: OFF

The Google provider callback remains:

`https://wvhhkipfbmfkvzpqoyvi.supabase.co/auth/v1/callback`

## 4. Supabase URL Configuration — REQUIRED ONCE

Authentication → URL Configuration → Redirect URLs → Add:

`cinenova://auth/callback`

Do not change the Google provider callback above.

The Android app opens Google through Supabase OAuth and returns to this custom app deep link after PKCE authentication.

## 5. Android package

Application ID / namespace:

`com.cinenova.shortvideo`

OAuth deep link:

`cinenova://auth/callback`

## 6. GitHub Actions

Upload the project files to a GitHub repository.

The workflow is:

`.github/workflows/build-apk.yml`

Then:

1. Open **Actions**
2. Select **CineNova Supabase APK Build**
3. Press **Run workflow**
4. Wait for the build
5. Open the successful run
6. Open **Artifacts**
7. Download `CineNova-Production-Supabase-APK`

The workflow checks project structure, checks that Firebase/service-role credentials are not accidentally included, runs `clean`, runs `assembleDebug`, verifies that an APK exists, and uploads it.

## Important build note

This project includes a Gradle wrapper JAR and wrapper properties. The wrapper downloads Gradle 9.3.1 on the first build. The current execution environment used to prepare this ZIP does not have an Android SDK or external network access, so an actual `assembleDebug` cannot be truthfully claimed as executed here. GitHub Actions has the required Android/JDK environment and is the intended build verification environment.

## No demo data

There are no hardcoded videos, fake users, fake likes, fake comments or fake followers. A fresh installation is empty until a real user signs in and publishes content.

## Account deletion

A secure account deletion endpoint should be implemented as a Supabase Edge Function before enabling one-tap deletion. The Android app deliberately does not contain a service-role key and therefore cannot safely delete an `auth.users` record directly.
