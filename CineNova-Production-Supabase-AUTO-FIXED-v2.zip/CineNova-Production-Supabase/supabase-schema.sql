-- CineNova production Supabase schema / upgrade script.
-- Safe to run after the base CineNova schema. No demo/seed rows are inserted.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null default '',
  avatar_url text not null default '',
  bio text not null default '',
  followers_count bigint not null default 0,
  following_count bigint not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default '',
  description text not null default '',
  video_url text not null,
  thumbnail_url text,
  duration_seconds integer not null default 0,
  visibility text not null default 'public' check (visibility in ('public','private','unlisted')),
  status text not null default 'published' check (status in ('draft','published','blocked','deleted')),
  likes_count bigint not null default 0,
  comments_count bigint not null default 0,
  views_count bigint not null default 0,
  hashtags text[] not null default '{}',
  allow_comments boolean not null default true,
  allow_downloads boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.videos add column if not exists hashtags text[] not null default '{}';
alter table public.videos add column if not exists allow_comments boolean not null default true;
alter table public.videos add column if not exists allow_downloads boolean not null default true;

create table if not exists public.likes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, video_id)
);
alter table public.likes add column if not exists video_id uuid;

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);
alter table public.comments add column if not exists video_id uuid;

create table if not exists public.follows (
  id uuid primary key default gen_random_uuid(),
  follower_id uuid not null references auth.users(id) on delete cascade,
  following_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  type text not null,
  message text not null default '',
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid references public.videos(id) on delete cascade,
  reported_user_id uuid references auth.users(id) on delete cascade,
  reason text not null,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.saved_videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, video_id)
);

create table if not exists public.watch_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  position_seconds bigint not null default 0,
  duration_seconds bigint not null default 0,
  updated_at timestamptz not null default now(),
  unique(user_id, video_id)
);

create index if not exists videos_feed_idx on public.videos(status, visibility, created_at desc);
create index if not exists videos_user_idx on public.videos(user_id, created_at desc);
create index if not exists likes_video_idx on public.likes(video_id);
create index if not exists comments_video_idx on public.comments(video_id, created_at desc);
create index if not exists follows_following_idx on public.follows(following_id);
create index if not exists follows_follower_idx on public.follows(follower_id);
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, username, display_name)
  values (
    new.id,
    'user_' || left(replace(new.id::text,'-',''), 10),
    coalesce(new.raw_user_meta_data->>'full_name', split_part(coalesce(new.email,''),'@',1), 'CineNova User')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.bump_video_counts()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if TG_TABLE_NAME = 'likes' then
    if TG_OP = 'INSERT' then update public.videos set likes_count = likes_count + 1 where id = new.video_id;
    elsif TG_OP = 'DELETE' then update public.videos set likes_count = greatest(likes_count - 1,0) where id = old.video_id; end if;
  elsif TG_TABLE_NAME = 'comments' then
    if TG_OP = 'INSERT' then update public.videos set comments_count = comments_count + 1 where id = new.video_id;
    elsif TG_OP = 'DELETE' then update public.videos set comments_count = greatest(comments_count - 1,0) where id = old.video_id; end if;
  end if;
  return coalesce(new,old);
end;
$$;

drop trigger if exists likes_count_trigger on public.likes;
create trigger likes_count_trigger after insert or delete on public.likes for each row execute function public.bump_video_counts();
drop trigger if exists comments_count_trigger on public.comments;
create trigger comments_count_trigger after insert or delete on public.comments for each row execute function public.bump_video_counts();

create or replace function public.bump_follow_counts()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if TG_OP='INSERT' then
    update public.profiles set following_count=following_count+1 where id=new.follower_id;
    update public.profiles set followers_count=followers_count+1 where id=new.following_id;
  elsif TG_OP='DELETE' then
    update public.profiles set following_count=greatest(following_count-1,0) where id=old.follower_id;
    update public.profiles set followers_count=greatest(followers_count-1,0) where id=old.following_id;
  end if;
  return coalesce(new,old);
end;
$$;
drop trigger if exists follows_count_trigger on public.follows;
create trigger follows_count_trigger after insert or delete on public.follows for each row execute function public.bump_follow_counts();

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.notifications enable row level security;
alter table public.reports enable row level security;
alter table public.saved_videos enable row level security;
alter table public.watch_history enable row level security;

-- Public feed/profile reads.
drop policy if exists "CineNova public published videos read" on public.videos;
create policy "CineNova public published videos read" on public.videos for select using (status='published' and visibility='public');
drop policy if exists "CineNova own videos all" on public.videos;
create policy "CineNova own videos all" on public.videos for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists "CineNova profiles public read" on public.profiles;
create policy "CineNova profiles public read" on public.profiles for select using (true);
drop policy if exists "CineNova own profile update" on public.profiles;
create policy "CineNova own profile update" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
drop policy if exists "CineNova own profile insert" on public.profiles;
create policy "CineNova own profile insert" on public.profiles for insert to authenticated with check (id=auth.uid());

-- Social actions.
drop policy if exists "CineNova likes read" on public.likes;
create policy "CineNova likes read" on public.likes for select using (true);
drop policy if exists "CineNova own likes" on public.likes;
create policy "CineNova own likes" on public.likes for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists "CineNova comments read" on public.comments;
create policy "CineNova comments read" on public.comments for select using (true);
drop policy if exists "CineNova own comments" on public.comments;
create policy "CineNova own comments" on public.comments for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists "CineNova follows read" on public.follows;
create policy "CineNova follows read" on public.follows for select using (true);
drop policy if exists "CineNova own follows" on public.follows;
create policy "CineNova own follows" on public.follows for all to authenticated using (follower_id=auth.uid()) with check (follower_id=auth.uid());
drop policy if exists "CineNova notifications own" on public.notifications;
create policy "CineNova notifications own" on public.notifications for select to authenticated using (user_id=auth.uid());
create policy "CineNova notifications mark read" on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists "CineNova reports own" on public.reports;
create policy "CineNova reports own" on public.reports for insert to authenticated with check (reporter_id=auth.uid());
drop policy if exists "CineNova saved read" on public.saved_videos;
create policy "CineNova saved read" on public.saved_videos for select to authenticated using (user_id=auth.uid());
drop policy if exists "CineNova own saved" on public.saved_videos;
create policy "CineNova own saved" on public.saved_videos for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists "CineNova history own" on public.watch_history;
create policy "CineNova history own" on public.watch_history for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create or replace function public.record_video_view(p_video_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.videos
  set views_count = views_count + 1
  where id = p_video_id and status = 'published' and visibility = 'public';
end;
$$;
grant execute on function public.record_video_view(uuid) to authenticated;

create or replace function public.create_social_notification()
returns trigger language plpgsql security definer set search_path = public as $$
declare target uuid; actor uuid; msg text; typ text;
begin
  actor := new.user_id;
  if TG_TABLE_NAME='likes' then
    select user_id into target from public.videos where id=new.video_id;
    typ := 'like'; msg := 'liked your video';
  elsif TG_TABLE_NAME='comments' then
    select user_id into target from public.videos where id=new.video_id;
    typ := 'comment'; msg := 'commented on your video';
  elsif TG_TABLE_NAME='follows' then
    target := new.following_id; actor := new.follower_id;
    typ := 'follow'; msg := 'started following you';
  else return new;
  end if;
  if target is not null and target <> actor then
    insert into public.notifications(user_id, actor_id, type, message) values(target, actor, typ, msg);
  end if;
  return new;
end;
$$;

drop trigger if exists like_notification_trigger on public.likes;
create trigger like_notification_trigger after insert on public.likes for each row execute function public.create_social_notification();
drop trigger if exists comment_notification_trigger on public.comments;
create trigger comment_notification_trigger after insert on public.comments for each row execute function public.create_social_notification();
drop trigger if exists follow_notification_trigger on public.follows;
create trigger follow_notification_trigger after insert on public.follows for each row execute function public.create_social_notification();

-- Add safe embedded profile fields to notification reads through a PostgREST relationship if desired.

-- Column-level hardening: clients cannot forge server-maintained counters/ownership.
revoke update (followers_count, following_count) on public.profiles from authenticated;
grant update (username, display_name, avatar_url, bio) on public.profiles to authenticated;
revoke update (user_id, likes_count, comments_count, views_count) on public.videos from authenticated;
grant insert on public.videos to authenticated;
grant update (title, description, thumbnail_url, visibility, status, hashtags, allow_comments, allow_downloads) on public.videos to authenticated;
grant insert, delete on public.likes to authenticated;
grant insert, delete on public.comments to authenticated;
grant insert, delete on public.follows to authenticated;
grant insert on public.reports to authenticated;
grant insert, delete on public.saved_videos to authenticated;
grant insert, update, delete on public.watch_history to authenticated;
drop policy if exists "CineNova notifications mark read" on public.notifications;
create policy "CineNova notifications mark read" on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
