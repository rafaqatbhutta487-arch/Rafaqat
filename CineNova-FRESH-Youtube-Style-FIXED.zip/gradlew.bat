@echo off
setlocal
set GRADLE_VERSION=9.3.1
set GRADLE_BASE=%USERPROFILE%\.gradle\cinenova-gradle
set GRADLE_HOME=%GRADLE_BASE%\gradle-%GRADLE_VERSION%
set GRADLE_ZIP=%GRADLE_BASE%\gradle-%GRADLE_VERSION%-bin.zip
set GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip

if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
if not exist "%GRADLE_BASE%" mkdir "%GRADLE_BASE%"
if not exist "%GRADLE_ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%GRADLE_URL%' -OutFile '%GRADLE_ZIP%'"
if exist "%GRADLE_HOME%" rmdir /s /q "%GRADLE_HOME%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%GRADLE_ZIP%' '%GRADLE_BASE%'"

:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
