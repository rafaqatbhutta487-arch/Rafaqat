package com.aistudio.cinenova.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CineDarkColorScheme = darkColorScheme(
  primary = CineRed,
  onPrimary = Color.White,
  primaryContainer = CineRedLight,
  onPrimaryContainer = Color.White,
  secondary = CineGold,
  onSecondary = Color.Black,
  secondaryContainer = CineDarkSurfaceVariant,
  onSecondaryContainer = CineGoldLight,
  tertiary = CineGold,
  onTertiary = Color.Black,
  background = CineDarkBackground,
  onBackground = CineTextPrimary,
  surface = CineDarkSurface,
  onSurface = CineTextPrimary,
  surfaceVariant = CineDarkSurfaceVariant,
  onSurfaceVariant = CineTextSecondary,
  outline = CineCardBorder,
  outlineVariant = CineCardBorder.copy(alpha = 0.5f),
  error = CineError,
  onError = Color.White
)

@Composable
fun CineNovaTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = CineDarkColorScheme,
    typography = Typography,
    content = content
  )
}
