package com.aistudio.cinenova.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.model.Comment
import com.aistudio.cinenova.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentBottomSheet(
  comments: List<Comment>,
  currentUserId: String,
  onDismiss: () -> Unit,
  onAddComment: (String) -> Unit,
  onDeleteComment: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var commentText by remember { mutableStateOf("") }
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = CineDarkSurface,
    contentColor = CineTextPrimary,
    modifier = modifier
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .padding(bottom = 16.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Comments (${comments.size})",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = CineTextPrimary
        )
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.size(32.dp)
        ) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = CineTextSecondary)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Comments List
      if (comments.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "No comments yet. Be the first to share your thoughts!",
            color = CineTextMuted,
            fontSize = 13.sp
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 340.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(comments, key = { it.commentId }) { comment ->
            CommentRow(
              comment = comment,
              isOwn = comment.userId == currentUserId,
              onDelete = { onDeleteComment(comment.commentId) }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Input Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .imePadding(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = commentText,
          onValueChange = { commentText = it },
          placeholder = { Text("Add a comment...", color = CineTextMuted, fontSize = 14.sp) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CineRed,
            unfocusedBorderColor = CineCardBorder,
            focusedTextColor = CineTextPrimary,
            unfocusedTextColor = CineTextPrimary,
            focusedContainerColor = CineDarkSurfaceVariant,
            unfocusedContainerColor = CineDarkSurfaceVariant
          ),
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("comment_input_field")
        )

        IconButton(
          onClick = {
            if (commentText.isNotBlank()) {
              onAddComment(commentText)
              commentText = ""
            }
          },
          enabled = commentText.isNotBlank(),
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(if (commentText.isNotBlank()) CineRed else CineDarkSurfaceVariant)
            .testTag("comment_send_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send Comment",
            tint = if (commentText.isNotBlank()) Color.White else CineTextMuted,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun CommentRow(
  comment: Comment,
  isOwn: Boolean,
  onDelete: () -> Unit
) {
  val dateFormatted = remember(comment.createdAt) {
    val sdf = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
    sdf.format(Date(comment.createdAt))
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(CineDarkSurfaceVariant.copy(alpha = 0.6f))
      .padding(10.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Avatar
    Box(
      modifier = Modifier
        .size(34.dp)
        .clip(CircleShape)
        .background(CineRed.copy(alpha = 0.3f)),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = comment.userName.take(1).uppercase(),
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
      )
    }

    Column(modifier = Modifier.weight(1f)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = comment.userName,
          color = CineTextPrimary,
          fontWeight = FontWeight.SemiBold,
          fontSize = 13.sp
        )
        Text(
          text = dateFormatted,
          color = CineTextMuted,
          fontSize = 11.sp
        )
      }

      Spacer(modifier = Modifier.height(3.dp))

      Text(
        text = comment.text,
        color = CineTextSecondary,
        fontSize = 13.sp,
        lineHeight = 18.sp
      )
    }

    if (isOwn) {
      IconButton(
        onClick = onDelete,
        modifier = Modifier.size(28.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Delete,
          contentDescription = "Delete Comment",
          tint = CineError.copy(alpha = 0.8f),
          modifier = Modifier.size(16.dp)
        )
      }
    }
  }
}
