package com.aistudio.cinenova.app.data.remote

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Small streaming client for Supabase Storage.
 *
 * The important part here is that the selected video is streamed from the
 * Android ContentResolver instead of calling readBytes(), which could load a
 * large video completely into RAM and crash the app.
 */
object SupabaseStorage {

  private const val SUPABASE_URL = "https://wvhhkipfbmfkvzpqoyvi.supabase.co"
  private const val SUPABASE_ANON_KEY = "sb_publishable_QHeXhDJpwEDv29GAv1vy_Q_jvBNfkvd"
  private const val VIDEO_BUCKET = "cinenova-videos"

  private val client = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(15, TimeUnit.MINUTES)
    .readTimeout(120, TimeUnit.SECONDS)
    .callTimeout(20, TimeUnit.MINUTES)
    .build()

  fun uploadFile(
    context: Context,
    uri: Uri,
    path: String,
    mimeType: String,
    bucket: String = VIDEO_BUCKET
  ): Result<String> {
    return try {
      val resolver = context.contentResolver
      val size = queryFileSize(resolver, uri)

      if (size == 0L) {
        return Result.failure(IOException("Selected file is empty or cannot be read."))
      }

      val mediaType = (mimeType.ifBlank { resolver.getType(uri) ?: "application/octet-stream" })
        .toMediaTypeOrNull()

      val body = ContentUriRequestBody(
        resolver = resolver,
        uri = uri,
        mediaType = mediaType,
        contentLength = size
      )

      // UUID-based paths contain no unsafe URL characters, but encode every
      // path segment anyway so this remains safe if the path format changes.
      val encodedPath = path.split('/').joinToString("/") { segment ->
        java.net.URLEncoder.encode(segment, Charsets.UTF_8.name()).replace("+", "%20")
      }

      val uploadUrl = "$SUPABASE_URL/storage/v1/object/$bucket/$encodedPath"

      val request = Request.Builder()
        .url(uploadUrl)
        .addHeader("apikey", SUPABASE_ANON_KEY)
        .addHeader("Authorization", "Bearer $SUPABASE_ANON_KEY")
        .addHeader("x-upsert", "false")
        .addHeader("cache-control", "3600")
        .post(body)
        .build()

      client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
          val errBody = response.body?.string()?.take(1000).orEmpty()
          Log.e("SupabaseStorage", "Upload failed: ${response.code} $errBody")
          return Result.failure(
            IOException("Storage upload failed (${response.code}). ${errBody.ifBlank { "Check bucket policies and storage configuration." }}")
          )
        }
      }

      val publicUrl = "$SUPABASE_URL/storage/v1/object/public/$bucket/$encodedPath"
      Result.success(publicUrl)
    } catch (e: Exception) {
      Log.e("SupabaseStorage", "Upload error", e)
      Result.failure(e)
    }
  }

  private fun queryFileSize(
    resolver: android.content.ContentResolver,
    uri: Uri
  ): Long? {
    var cursor: Cursor? = null
    return try {
      cursor = resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
      if (cursor != null && cursor.moveToFirst()) {
        val index = cursor.getColumnIndex(OpenableColumns.SIZE)
        if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index) else null
      } else {
        null
      }
    } catch (_: Exception) {
      null
    } finally {
      cursor?.close()
    }
  }

  private class ContentUriRequestBody(
    private val resolver: android.content.ContentResolver,
    private val uri: Uri,
    private val mediaType: okhttp3.MediaType?,
    private val contentLength: Long?
  ) : RequestBody() {

    override fun contentType(): okhttp3.MediaType? = mediaType

    override fun contentLength(): Long = contentLength ?: -1L

    override fun writeTo(sink: BufferedSink) {
      resolver.openInputStream(uri)?.use { input ->
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        while (true) {
          val read = input.read(buffer)
          if (read < 0) break
          sink.write(buffer, 0, read)
        }
      } ?: throw IOException("Could not open selected video file")
    }
  }
}
