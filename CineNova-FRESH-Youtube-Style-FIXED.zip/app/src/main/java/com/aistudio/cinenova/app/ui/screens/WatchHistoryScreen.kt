package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun WatchHistoryScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  onBackClick: () -> Unit,
  onPlayClick: (String) -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val watchHistory by repository.watchHistory.collectAsState()
  var showClearConfirm by remember { mutableStateOf(false) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .statusBarsPadding()
      .testTag("watch_history_screen")
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBackClick) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Watch History",
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 20.sp
        )
      }

      if (watchHistory.isNotEmpty()) {
        IconButton(onClick = { showClearConfirm = true }) {
          Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All", tint = CineTextMuted)
        }
      }
    }

    if (watchHistory.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No watch history recorded yet.\nStart streaming any movie or short to track progress here.",
          color = CineTextMuted,
          fontSize = 14.sp,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center,
          lineHeight = 22.sp
        )
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(watchHistory, key = { it.historyId }) { item ->
          val dateStr = remember(item.updatedAt) {
            val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            sdf.format(Date(item.updatedAt))
          }

          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .clickable { onPlayClick(item.videoId) }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              AsyncImage(
                model = ImageRequest.Builder(context)
                  .data(item.poster)
                  .crossfade(true)
                  .build(),
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                  .width(80.dp)
                  .height(100.dp)
                  .clip(RoundedCornerShape(8.dp))
              )

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = item.title,
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
                Text(
                  text = "Watched on $dateStr",
                  color = CineTextMuted,
                  fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Progress Bar
                LinearProgressIndicator(
                  progress = { (item.progressPercentage / 100f).coerceIn(0f, 1f) },
                  color = CineRed,
                  trackColor = CineDarkSurfaceVariant,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "${item.progressPercentage}% completed",
                    color = CineGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CineRed, modifier = Modifier.size(16.dp))
                    Text(text = "Resume", color = CineRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Clear Confirmation
  if (showClearConfirm) {
    AlertDialog(
      onDismissRequest = { showClearConfirm = false },
      containerColor = CineDarkSurface,
      title = { Text("Clear Watch History?", color = Color.White, fontWeight = FontWeight.Bold) },
      text = { Text("This will erase all your playback positions and saved watch history records.", color = CineTextSecondary, fontSize = 14.sp) },
      confirmButton = {
        Button(
          onClick = {
            scope.launch {
              repository.clearWatchHistory(currentUserId)
              showClearConfirm = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = CineError)
        ) {
          Text("Clear All", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearConfirm = false }) {
          Text("Cancel", color = CineTextSecondary)
        }
      }
    )
  }
}
