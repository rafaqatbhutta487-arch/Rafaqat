package com.aistudio.cinenova.app.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadVideoScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  currentUserName: String,
  onBackClick: () -> Unit,
  onUploadSuccess: () -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  var isShortVideo by remember { mutableStateOf(false) }
  var title by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(repository.categories.firstOrNull() ?: "Action") }
  var tags by remember { mutableStateOf("") }

  var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
  var selectedThumbnailUri by remember { mutableStateOf<Uri?>(null) }

  var isUploading by remember { mutableStateOf(false) }
  var uploadProgress by remember { mutableFloatStateOf(0f) }
  var categoryExpanded by remember { mutableStateOf(false) }

  // Video Picker Launcher
  val videoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri ->
    selectedVideoUri = uri
  }

  // Thumbnail Picker Launcher
  val thumbnailPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri ->
    selectedThumbnailUri = uri
  }

  fun performUpload() {
    if (selectedVideoUri == null) {
      Toast.makeText(context, "Please select a video file", Toast.LENGTH_SHORT).show()
      return
    }
    if (title.isBlank()) {
      Toast.makeText(context, "Please provide a video title", Toast.LENGTH_SHORT).show()
      return
    }

    isUploading = true
    uploadProgress = 0.05f

    scope.launch {
      val parsedTags = tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }

      val result = repository.uploadVideo(
        userId = currentUserId,
        userName = currentUserName,
        title = title.trim(),
        description = description.trim(),
        category = selectedCategory,
        tags = parsedTags,
        isShort = isShortVideo,
        videoUri = selectedVideoUri!!,
        posterUri = selectedThumbnailUri,
        onProgress = { progressInt ->
          uploadProgress = progressInt / 100f
        }
      )

      isUploading = false
      result.fold(
        onSuccess = {
          Toast.makeText(context, "Video uploaded and published to CineNova!", Toast.LENGTH_LONG).show()
          onUploadSuccess()
        },
        onFailure = { err ->
          Toast.makeText(context, "Upload failed: ${err.message}", Toast.LENGTH_LONG).show()
        }
      )
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .statusBarsPadding()
      .testTag("upload_video_screen")
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClick, enabled = !isUploading) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "Upload Video",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
      )
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 8.dp)
        .padding(bottom = 40.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Content Type Selector: Movie vs CineShort
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = CineDarkSurface,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (!isShortVideo) CineRed else Color.Transparent)
              .clickable(enabled = !isUploading) { isShortVideo = false }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Full Movie",
              color = if (!isShortVideo) Color.White else CineTextSecondary,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }

          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isShortVideo) CineRed else Color.Transparent)
              .clickable(enabled = !isUploading) { isShortVideo = true }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "CineShort (Vertical)",
              color = if (isShortVideo) Color.White else CineTextSecondary,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }

      // Video File Picker Card
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (selectedVideoUri != null) CineGold else CineCardBorder
        ),
        modifier = Modifier
          .fillMaxWidth()
          .clickable(enabled = !isUploading) {
            videoPickerLauncher.launch("video/*")
          }
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Box(
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(if (selectedVideoUri != null) CineGold.copy(alpha = 0.2f) else CineDarkSurfaceVariant),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (selectedVideoUri != null) Icons.Default.CheckCircle else Icons.Default.VideoFile,
              contentDescription = null,
              tint = if (selectedVideoUri != null) CineGold else CineTextSecondary
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (selectedVideoUri != null) "Video File Selected" else "Select Video File",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            Text(
              text = selectedVideoUri?.lastPathSegment ?: "Tap to choose an MP4/MKV video from your device",
              color = CineTextSecondary,
              fontSize = 12.sp,
              maxLines = 1
            )
          }

          Text(
            text = if (selectedVideoUri != null) "Change" else "Browse",
            color = CineRed,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
        }
      }

      // Thumbnail Image Picker Card
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (selectedThumbnailUri != null) CineGold else CineCardBorder
        ),
        modifier = Modifier
          .fillMaxWidth()
          .clickable(enabled = !isUploading) {
            thumbnailPickerLauncher.launch("image/*")
          }
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          if (selectedThumbnailUri != null) {
            AsyncImage(
              model = selectedThumbnailUri,
              contentDescription = "Selected Thumbnail",
              modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(8.dp))
            )
          } else {
            Box(
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(CineDarkSurfaceVariant),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Image, contentDescription = null, tint = CineTextSecondary)
            }
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (selectedThumbnailUri != null) "Thumbnail Selected" else "Select Thumbnail / Poster",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            Text(
              text = if (selectedThumbnailUri != null) "Custom cover ready" else "Optional: pick custom cover art",
              color = CineTextSecondary,
              fontSize = 12.sp
            )
          }

          Text(
            text = if (selectedThumbnailUri != null) "Change" else "Browse",
            color = CineRed,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
        }
      }

      // Metadata form fields
      OutlinedTextField(
        value = title,
        onValueChange = { title = it },
        label = { Text("Title") },
        enabled = !isUploading,
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CineRed,
          unfocusedBorderColor = CineCardBorder,
          focusedTextColor = CineTextPrimary,
          unfocusedTextColor = CineTextPrimary,
          focusedContainerColor = CineDarkSurface,
          unfocusedContainerColor = CineDarkSurface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("upload_title_input")
      )

      OutlinedTextField(
        value = description,
        onValueChange = { description = it },
        label = { Text("Description") },
        minLines = 3,
        maxLines = 5,
        enabled = !isUploading,
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CineRed,
          unfocusedBorderColor = CineCardBorder,
          focusedTextColor = CineTextPrimary,
          unfocusedTextColor = CineTextPrimary,
          focusedContainerColor = CineDarkSurface,
          unfocusedContainerColor = CineDarkSurface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      )

      // Category Dropdown
      ExposedDropdownMenuBox(
        expanded = categoryExpanded,
        onExpandedChange = { if (!isUploading) categoryExpanded = !categoryExpanded }
      ) {
        OutlinedTextField(
          value = selectedCategory,
          onValueChange = {},
          readOnly = true,
          label = { Text("Category") },
          trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CineRed,
            unfocusedBorderColor = CineCardBorder,
            focusedTextColor = CineTextPrimary,
            unfocusedTextColor = CineTextPrimary,
            focusedContainerColor = CineDarkSurface,
            unfocusedContainerColor = CineDarkSurface
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .menuAnchor()
        )

        ExposedDropdownMenu(
          expanded = categoryExpanded,
          onDismissRequest = { categoryExpanded = false },
          modifier = Modifier.background(CineDarkSurface)
        ) {
          repository.categories.filter { it != "All" }.forEach { cat ->
            DropdownMenuItem(
              text = { Text(cat, color = CineTextPrimary) },
              onClick = {
                selectedCategory = cat
                categoryExpanded = false
              }
            )
          }
        }
      }

      OutlinedTextField(
        value = tags,
        onValueChange = { tags = it },
        label = { Text("Tags (comma separated, e.g. 4k, trailer, scifi)") },
        enabled = !isUploading,
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CineRed,
          unfocusedBorderColor = CineCardBorder,
          focusedTextColor = CineTextPrimary,
          unfocusedTextColor = CineTextPrimary,
          focusedContainerColor = CineDarkSurface,
          unfocusedContainerColor = CineDarkSurface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      )

      // Upload Progress indicator
      if (isUploading) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Uploading to Cloud Storage...", color = CineGoldLight, fontSize = 12.sp)
            Text("${(uploadProgress * 100).toInt()}%", color = CineGoldLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
          LinearProgressIndicator(
            progress = { uploadProgress },
            color = CineRed,
            trackColor = CineDarkSurfaceVariant,
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp))
          )
        }
      }

      // Submit Upload Button
      Button(
        onClick = { performUpload() },
        enabled = !isUploading,
        colors = ButtonDefaults.buttonColors(containerColor = CineRed),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("submit_upload_button")
      ) {
        if (isUploading) {
          CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
        } else {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Publish to CineNova", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
        }
      }
    }
  }
}
