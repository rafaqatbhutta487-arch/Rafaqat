package com.aistudio.cinenova.app.player

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlayerState(
  val isPlaying: Boolean = false,
  val currentPosition: Long = 0L,
  val duration: Long = 0L,
  val isBuffering: Boolean = false,
  val isEnded: Boolean = false,
  val error: String? = null,
  val isMuted: Boolean = false
)

/**
 * Owns exactly one Media3 player for one screen instance.
 *
 * The previous implementation could repeatedly rebuild the player and was not
 * defensive about malformed/empty URLs. This version validates the URL,
 * isolates player callbacks from Compose state, and guarantees release of the
 * player and polling coroutine.
 */
@OptIn(UnstableApi::class)
class ExoPlayerManager(context: Context) {
  private val appContext = context.applicationContext

  var player: ExoPlayer? = null
    private set

  private val _state = MutableStateFlow(PlayerState())
  val state: StateFlow<PlayerState> = _state.asStateFlow()

  private var positionPollingJob: Job? = null
  private val scope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())

  private var currentUrl: String? = null

  fun initializePlayer(videoUrl: String, startPositionMs: Long = 0L) {
    val url = videoUrl.trim()

    if (!isPlayableHttpUrl(url)) {
      releasePlayerOnly()
      _state.value = PlayerState(error = "Invalid video URL. Please re-upload the video.")
      return
    }

    // Do not rebuild the player just because Compose recomposed. Only replace
    // it when the actual URL changes or there is no player yet.
    if (currentUrl == url && player != null) {
      return
    }

    releasePlayerOnly()
    currentUrl = url

    try {
      val exoPlayer = ExoPlayer.Builder(appContext).build()

      exoPlayer.addListener(object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
          val isBuffering = playbackState == Player.STATE_BUFFERING
          val isEnded = playbackState == Player.STATE_ENDED
          val duration = exoPlayer.duration.takeIf { it >= 0L } ?: 0L

          _state.value = _state.value.copy(
            isBuffering = isBuffering,
            isEnded = isEnded,
            duration = duration,
            error = if (playbackState == Player.STATE_IDLE) _state.value.error else null
          )
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
          _state.value = _state.value.copy(isPlaying = isPlaying)
        }

        override fun onPlayerError(error: PlaybackException) {
          Log.e("CineNovaPlayer", "Media3 playback error", error)
          _state.value = _state.value.copy(
            error = "Video cannot be played: ${error.localizedMessage ?: "unsupported stream or network error"}",
            isBuffering = false,
            isPlaying = false
          )
        }
      })

      exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
      player = exoPlayer
      startPositionPolling()

      exoPlayer.prepare()
      if (startPositionMs > 0L) {
        exoPlayer.seekTo(startPositionMs.coerceAtLeast(0L))
      }
      exoPlayer.playWhenReady = true
    } catch (error: Exception) {
      Log.e("CineNovaPlayer", "Failed to initialize player", error)
      player = null
      currentUrl = null
      _state.value = PlayerState(
        error = "Unable to start video: ${error.localizedMessage ?: "player initialization failed"}"
      )
    }
  }

  private fun startPositionPolling() {
    positionPollingJob?.cancel()
    positionPollingJob = scope.launch {
      while (isActive) {
        val p = player
        if (p != null) {
          val position = p.currentPosition.coerceAtLeast(0L)
          val duration = p.duration.takeIf { it >= 0L } ?: 0L
          _state.value = _state.value.copy(
            currentPosition = position,
            duration = duration
          )
        }
        delay(500)
      }
    }
  }

  fun play() {
    runCatching { player?.play() }
      .onFailure { Log.w("CineNovaPlayer", "play() failed", it) }
  }

  fun pause() {
    runCatching { player?.pause() }
      .onFailure { Log.w("CineNovaPlayer", "pause() failed", it) }
  }

  fun togglePlayPause() {
    val p = player ?: return
    runCatching {
      if (p.isPlaying) p.pause() else p.play()
    }.onFailure {
      Log.w("CineNovaPlayer", "togglePlayPause() failed", it)
    }
  }

  fun seekTo(positionMs: Long) {
    val p = player ?: return
    runCatching { p.seekTo(positionMs.coerceAtLeast(0L)) }
      .onFailure { Log.w("CineNovaPlayer", "seekTo() failed", it) }
  }

  fun forward10Seconds() {
    val p = player ?: return
    val duration = p.duration.takeIf { it >= 0L } ?: Long.MAX_VALUE
    runCatching {
      p.seekTo((p.currentPosition + 10_000L).coerceAtMost(duration))
    }.onFailure { Log.w("CineNovaPlayer", "forward failed", it) }
  }

  fun rewind10Seconds() {
    val p = player ?: return
    runCatching {
      p.seekTo((p.currentPosition - 10_000L).coerceAtLeast(0L))
    }.onFailure { Log.w("CineNovaPlayer", "rewind failed", it) }
  }

  fun toggleMute() {
    val p = player ?: return
    val newMute = !_state.value.isMuted
    runCatching {
      p.volume = if (newMute) 0f else 1f
      _state.value = _state.value.copy(isMuted = newMute)
    }.onFailure { Log.w("CineNovaPlayer", "mute toggle failed", it) }
  }

  fun retry(videoUrl: String) {
    val position = _state.value.currentPosition
    currentUrl = null
    initializePlayer(videoUrl, position)
  }

  fun release() {
    releasePlayerOnly()
    currentUrl = null
    _state.value = PlayerState()
  }

  private fun releasePlayerOnly() {
    positionPollingJob?.cancel()
    positionPollingJob = null

    val oldPlayer = player
    player = null

    runCatching { oldPlayer?.stop() }
    runCatching { oldPlayer?.clearMediaItems() }
    runCatching { oldPlayer?.release() }
  }

  private fun isPlayableHttpUrl(value: String): Boolean {
    return value.startsWith("https://", ignoreCase = true) ||
      value.startsWith("http://", ignoreCase = true)
  }

  fun close() {
    release()
    scope.cancel()
  }
}
