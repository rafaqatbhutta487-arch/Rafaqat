package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun WatchlistScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  onBackClick: () -> Unit,
  onMovieClick: (String) -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val watchlist by repository.watchlist.collectAsState()
  val movies by repository.movies.collectAsState()

  val watchlistMovies = remember(watchlist, movies) {
    watchlist.mapNotNull { item -> movies.find { it.movieId == item.videoId } }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .statusBarsPadding()
      .testTag("watchlist_screen")
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClick) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "My Watchlist (${watchlist.size})",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
      )
    }

    if (watchlistMovies.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "Your watchlist is currently empty.\nExplore movies and tap + Watchlist to save them here.",
          color = CineTextMuted,
          fontSize = 14.sp,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center,
          lineHeight = 22.sp
        )
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(watchlistMovies, key = { it.movieId }) { movie ->
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .clickable { onMovieClick(movie.movieId) }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              AsyncImage(
                model = ImageRequest.Builder(context)
                  .data(movie.poster)
                  .crossfade(true)
                  .build(),
                contentDescription = movie.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                  .width(70.dp)
                  .height(95.dp)
                  .clip(RoundedCornerShape(8.dp))
              )

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = movie.title,
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp
                )
                Text(
                  text = "${movie.category} • ${movie.year} • ${movie.duration}",
                  color = CineTextSecondary,
                  fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CineRed, modifier = Modifier.size(16.dp))
                  Text(text = "Watch now", color = CineRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
              }

              IconButton(
                onClick = {
                  scope.launch {
                    repository.toggleWatchlist(currentUserId, movie)
                  }
                }
              ) {
                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = CineTextMuted)
              }
            }
          }
        }
      }
    }
  }
}
