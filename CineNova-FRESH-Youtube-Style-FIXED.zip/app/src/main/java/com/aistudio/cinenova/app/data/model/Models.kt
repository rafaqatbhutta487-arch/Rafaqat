package com.aistudio.cinenova.app.data.model

import androidx.annotation.Keep

@Keep
data class User(
  val userId: String = "",
  val name: String = "",
  val email: String = "",
  val profileImage: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val status: String = "active"
)

@Keep
data class Movie(
  val movieId: String = "",
  val title: String = "",
  val description: String = "",
  val poster: String = "",
  val backdrop: String = "",
  val videoUrl: String = "",
  val category: String = "Action",
  val tags: List<String> = emptyList(),
  val year: Int = 2024,
  val duration: String = "1h 45m",
  val durationSeconds: Long = 6300L,
  val rating: Double = 8.5,
  val views: Long = 0L,
  val likes: Long = 0L,
  val published: Boolean = true,
  val createdAt: Long = System.currentTimeMillis(),
  val uploaderId: String = "", // userId of the person who uploaded this (empty = curated/seed content)
  val uploaderName: String = ""
)

@Keep
data class ShortVideo(
  val shortId: String = "",
  val title: String = "",
  val description: String = "",
  val videoUrl: String = "",
  val thumbnail: String = "",
  val creatorId: String = "",
  val creatorName: String = "CineNova Creator",
  val views: Long = 0L,
  val likes: Long = 0L,
  val commentsCount: Long = 0L,
  val published: Boolean = true,
  val createdAt: Long = System.currentTimeMillis()
)

@Keep
data class WatchHistoryItem(
  val historyId: String = "",
  val userId: String = "",
  val videoId: String = "",
  val title: String = "",
  val poster: String = "",
  val videoUrl: String = "",
  val positionSeconds: Long = 0L,
  val totalDurationSeconds: Long = 0L,
  val progressPercentage: Int = 0,
  val updatedAt: Long = System.currentTimeMillis()
)

@Keep
data class WatchlistItem(
  val watchlistId: String = "",
  val userId: String = "",
  val videoId: String = "",
  val title: String = "",
  val poster: String = "",
  val category: String = "",
  val rating: Double = 0.0,
  val year: Int = 2024,
  val addedAt: Long = System.currentTimeMillis()
)

@Keep
data class LikeItem(
  val likeId: String = "",
  val userId: String = "",
  val contentId: String = "",
  val contentType: String = "movie", // "movie" or "short"
  val createdAt: Long = System.currentTimeMillis()
)

@Keep
data class Comment(
  val commentId: String = "",
  val userId: String = "",
  val userName: String = "Movie Fan",
  val userAvatar: String = "",
  val contentId: String = "",
  val text: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Keep
data class TaskItem(
  val taskId: String = "",
  val title: String = "",
  val description: String = "",
  val reward: Int = 50,
  val dailyLimit: Int = 1,
  val active: Boolean = true,
  val targetType: String = "watch_movie", // "login", "watch_movie", "watch_short", "promo_poster"
  val targetCount: Int = 1,
  val startDate: Long = 0L,
  val endDate: Long = Long.MAX_VALUE
)

@Keep
data class TaskCompletion(
  val completionId: String = "",
  val userId: String = "",
  val taskId: String = "",
  val date: String = "", // YYYY-MM-DD
  val completed: Boolean = false,
  val claimed: Boolean = false,
  val currentProgress: Int = 0,
  val rewardTransactionId: String = ""
)

@Keep
data class CoinBalance(
  val userId: String = "",
  val balance: Long = 150L,
  val dailyEarned: Long = 0L,
  val lastEarnedDate: String = "" // YYYY-MM-DD
)

@Keep
data class CoinTransaction(
  val transactionId: String = "",
  val userId: String = "",
  val amount: Int = 0,
  val reason: String = "",
  val taskId: String = "",
  val balanceAfter: Long = 0L,
  val timestamp: Long = System.currentTimeMillis()
)

@Keep
data class PromotionCampaign(
  val campaignId: String = "",
  val title: String = "",
  val description: String = "",
  val sponsor: String = "CineNova Studios",
  val poster: String = "",
  val durationSeconds: Int = 30, // active watch duration required
  val reward: Int = 100,
  val dailyLimit: Int = 1,
  val startDate: Long = 0L,
  val endDate: Long = Long.MAX_VALUE,
  val active: Boolean = true
)
