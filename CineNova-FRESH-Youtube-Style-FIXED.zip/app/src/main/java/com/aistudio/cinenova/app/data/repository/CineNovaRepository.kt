package com.aistudio.cinenova.app.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.aistudio.cinenova.app.data.model.*
import com.aistudio.cinenova.app.data.remote.SupabaseStorage
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class CineNovaRepository(private val context: Context) {
  private val firestore: FirebaseFirestore? = try {
    FirebaseFirestore.getInstance()
  } catch (e: Exception) {
    Log.w("CineNovaRepository", "Firestore not available: ${e.message}")
    null
  }

  private val prefs = context.getSharedPreferences("cinenova_local_db", Context.MODE_PRIVATE)

  private companion object {
    const val LOCAL_UPLOADED_MOVIES = "local_uploaded_movies_v1"
    const val LOCAL_UPLOADED_SHORTS = "local_uploaded_shorts_v1"
  }

  // Seed default curated high quality streaming content
  // No demo/seed movies. Only published user uploads are shown.
  private val initialMovies = emptyList<Movie>()

  // No demo/seed shorts. Only published user uploads are shown.
  private val initialShorts = emptyList<ShortVideo>()

  // Start with no seeded reward tasks/content.
  private val initialTasks = emptyList<TaskItem>()

  private val initialCampaign = PromotionCampaign(
    campaignId = "camp_cinenova_gala_2024",
    title = "CineNova World Premiere Gala 2024",
    description = "Celebrate the launch of CineNova with exclusive cinematic previews and director commentaries. View this showcase for 30 seconds to claim 100 reward coins!",
    poster = "android.resource://" + context.packageName + "/drawable/promo_campaign_poster",
    durationSeconds = 30,
    reward = 100,
    dailyLimit = 1,
    active = true
  )

  val defaultCampaign: PromotionCampaign = initialCampaign

  // In-memory / reactive states
  private val _movies = MutableStateFlow<List<Movie>>(mergeMovies(initialMovies, loadLocalUploadedMovies()))
  val movies: StateFlow<List<Movie>> = _movies.asStateFlow()

  private val _shorts = MutableStateFlow<List<ShortVideo>>(mergeShorts(initialShorts, loadLocalUploadedShorts()))
  val shorts: StateFlow<List<ShortVideo>> = _shorts.asStateFlow()

  private val _watchlist = MutableStateFlow<List<WatchlistItem>>(emptyList())
  val watchlist: StateFlow<List<WatchlistItem>> = _watchlist.asStateFlow()

  private val _watchHistory = MutableStateFlow<List<WatchHistoryItem>>(emptyList())
  val watchHistory: StateFlow<List<WatchHistoryItem>> = _watchHistory.asStateFlow()

  private val _coinBalance = MutableStateFlow(CoinBalance(balance = 150L, dailyEarned = 0L))
  val coinBalance: StateFlow<CoinBalance> = _coinBalance.asStateFlow()

  private val _coinTransactions = MutableStateFlow<List<CoinTransaction>>(emptyList())
  val coinTransactions: StateFlow<List<CoinTransaction>> = _coinTransactions.asStateFlow()

  private val _tasks = MutableStateFlow<List<TaskItem>>(initialTasks)
  val tasks: StateFlow<List<TaskItem>> = _tasks.asStateFlow()

  private val _taskCompletions = MutableStateFlow<Map<String, TaskCompletion>>(emptyMap())
  val taskCompletions: StateFlow<Map<String, TaskCompletion>> = _taskCompletions.asStateFlow()

  private val _userLikes = MutableStateFlow<Set<String>>(emptySet())
  val userLikes: StateFlow<Set<String>> = _userLikes.asStateFlow()

  private val _campaign = MutableStateFlow(initialCampaign)
  val campaign: StateFlow<PromotionCampaign> = _campaign.asStateFlow()

  val categories = listOf("All", "Action", "Sci-Fi", "Animation", "Comedy", "Drama", "Thriller", "Horror", "Documentary")

  fun getTodayDateKey(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return sdf.format(Date())
  }

  suspend fun initializeData(userId: String) = withContext(Dispatchers.IO) {
    // Load coins, watchlist, history from local prefs or firestore
    val savedBalance = prefs.getLong("coin_balance_${userId}", 150L)
    val savedDailyEarned = prefs.getLong("coin_daily_${userId}_${getTodayDateKey()}", 0L)
    _coinBalance.value = CoinBalance(
      userId = userId,
      balance = savedBalance,
      dailyEarned = savedDailyEarned,
      lastEarnedDate = getTodayDateKey()
    )

    // Load initial welcome bonus transaction if empty
    if (_coinTransactions.value.isEmpty()) {
      val welcomeTxn = CoinTransaction(
        transactionId = "TXN-INIT-${UUID.randomUUID().toString().take(8).uppercase()}",
        userId = userId,
        amount = 150,
        reason = "CineNova Welcome Bonus",
        taskId = "welcome_reward",
        balanceAfter = savedBalance,
        timestamp = System.currentTimeMillis() - 3600000
      )
      _coinTransactions.value = listOf(welcomeTxn)
    }

    // Attempt to sync from Firestore if available
    firestore?.let { db ->
      try {
        // Sync movies
        val movieDocs = db.collection("movies").whereEqualTo("published", true).get().await()
        val remoteMovies = movieDocs.documents.mapNotNull { it.toObject(Movie::class.java) }
        _movies.value = mergeMovies(remoteMovies, loadLocalUploadedMovies())

        // Sync shorts
        val shortDocs = db.collection("shorts").whereEqualTo("published", true).get().await()
        val remoteShorts = shortDocs.documents.mapNotNull { it.toObject(ShortVideo::class.java) }
        _shorts.value = mergeShorts(remoteShorts, loadLocalUploadedShorts())

        // Sync watchlist for user
        val watchlistDocs = db.collection("watchlist").whereEqualTo("userId", userId).get().await()
        _watchlist.value = watchlistDocs.documents.mapNotNull { it.toObject(WatchlistItem::class.java) }

        // Sync watch history for user
        val historyDocs = db.collection("watch_history")
          .whereEqualTo("userId", userId)
          .orderBy("updatedAt", Query.Direction.DESCENDING)
          .get().await()
        _watchHistory.value = historyDocs.documents.mapNotNull { it.toObject(WatchHistoryItem::class.java) }

        // Sync likes for user
        val likesDocs = db.collection("likes").whereEqualTo("userId", userId).get().await()
        val likedIds = likesDocs.documents.mapNotNull { it.getString("contentId") }.toSet()
        _userLikes.value = likedIds

      } catch (e: Exception) {
        Log.w("CineNovaRepository", "Firestore sync warning: ${e.message}")
      }
    }
  }

  // Watchlist methods
  suspend fun toggleWatchlist(userId: String, movie: Movie): Boolean = withContext(Dispatchers.IO) {
    val current = _watchlist.value.toMutableList()
    val existingIndex = current.indexOfFirst { it.videoId == movie.movieId }
    val isAdded: Boolean
    if (existingIndex >= 0) {
      val item = current.removeAt(existingIndex)
      firestore?.collection("watchlist")?.document(item.watchlistId)?.delete()
      isAdded = false
    } else {
      val newItem = WatchlistItem(
        watchlistId = "wl_${userId}_${movie.movieId}",
        userId = userId,
        videoId = movie.movieId,
        title = movie.title,
        poster = movie.poster,
        category = movie.category,
        rating = movie.rating,
        year = movie.year,
        addedAt = System.currentTimeMillis()
      )
      current.add(0, newItem)
      firestore?.collection("watchlist")?.document(newItem.watchlistId)?.set(newItem)
      isAdded = true
    }
    _watchlist.value = current
    isAdded
  }

  fun isInWatchlist(movieId: String): Boolean {
    return _watchlist.value.any { it.videoId == movieId }
  }

  // Like methods
  suspend fun toggleLike(userId: String, contentId: String, contentType: String): Boolean = withContext(Dispatchers.IO) {
    val currentLikes = _userLikes.value.toMutableSet()
    val isLiked = currentLikes.contains(contentId)
    val newLikedState = !isLiked

    if (newLikedState) {
      currentLikes.add(contentId)
      val likeItem = LikeItem(
        likeId = "like_${userId}_${contentId}",
        userId = userId,
        contentId = contentId,
        contentType = contentType,
        createdAt = System.currentTimeMillis()
      )
      firestore?.collection("likes")?.document(likeItem.likeId)?.set(likeItem)
    } else {
      currentLikes.remove(contentId)
      firestore?.collection("likes")?.document("like_${userId}_${contentId}")?.delete()
    }
    _userLikes.value = currentLikes

    // Update count in movie or short
    if (contentType == "movie") {
      _movies.value = _movies.value.map {
        if (it.movieId == contentId) {
          val delta = if (newLikedState) 1L else -1L
          val updated = it.copy(likes = (it.likes + delta).coerceAtLeast(0L))
          firestore?.collection("movies")?.document(contentId)?.update("likes", updated.likes)
          updated
        } else it
      }
    } else {
      _shorts.value = _shorts.value.map {
        if (it.shortId == contentId) {
          val delta = if (newLikedState) 1L else -1L
          val updated = it.copy(likes = (it.likes + delta).coerceAtLeast(0L))
          firestore?.collection("shorts")?.document(contentId)?.update("likes", updated.likes)
          updated
        } else it
      }
    }

    newLikedState
  }

  fun isContentLiked(contentId: String): Boolean {
    return _userLikes.value.contains(contentId)
  }

  // Watch History & Continue Watching
  suspend fun updateWatchProgress(
    userId: String,
    movie: Movie,
    positionSec: Long,
    totalDurationSec: Long
  ) = withContext(Dispatchers.IO) {
    if (positionSec <= 0 || totalDurationSec <= 0) return@withContext
    val progressPct = ((positionSec.toDouble() / totalDurationSec) * 100).toInt().coerceIn(0, 100)

    val current = _watchHistory.value.toMutableList()
    val existingIndex = current.indexOfFirst { it.videoId == movie.movieId }
    val item = WatchHistoryItem(
      historyId = "wh_${userId}_${movie.movieId}",
      userId = userId,
      videoId = movie.movieId,
      title = movie.title,
      poster = movie.poster,
      videoUrl = movie.videoUrl,
      positionSeconds = positionSec,
      totalDurationSeconds = totalDurationSec,
      progressPercentage = progressPct,
      updatedAt = System.currentTimeMillis()
    )

    if (existingIndex >= 0) {
      current[existingIndex] = item
    } else {
      current.add(0, item)
    }
    _watchHistory.value = current.sortedByDescending { it.updatedAt }

    firestore?.collection("watch_history")?.document(item.historyId)?.set(item)

    // Check task progress for watch_movie
    if (positionSec >= 30) {
      recordTaskProgress(userId, "task_watch_movie", 1)
    }
  }

  suspend fun removeWatchHistory(historyId: String) = withContext(Dispatchers.IO) {
    _watchHistory.value = _watchHistory.value.filterNot { it.historyId == historyId }
    firestore?.collection("watch_history")?.document(historyId)?.delete()
  }

  suspend fun clearWatchHistory(userId: String) = withContext(Dispatchers.IO) {
    _watchHistory.value = emptyList()
    firestore?.collection("watch_history")
      ?.whereEqualTo("userId", userId)
      ?.get()?.await()?.documents?.forEach { it.reference.delete() }
  }

  // Views tracking with debounce
  private val viewedContentInSession = mutableSetOf<String>()
  suspend fun recordView(contentId: String, isShort: Boolean) = withContext(Dispatchers.IO) {
    if (viewedContentInSession.contains(contentId)) return@withContext
    viewedContentInSession.add(contentId)

    if (isShort) {
      _shorts.value = _shorts.value.map {
        if (it.shortId == contentId) {
          val updated = it.copy(views = it.views + 1)
          firestore?.collection("shorts")?.document(contentId)?.update("views", updated.views)
          updated
        } else it
      }
    } else {
      _movies.value = _movies.value.map {
        if (it.movieId == contentId) {
          val updated = it.copy(views = it.views + 1)
          firestore?.collection("movies")?.document(contentId)?.update("views", updated.views)
          updated
        } else it
      }
    }
  }

  // Comments
  suspend fun getComments(contentId: String): List<Comment> = withContext(Dispatchers.IO) {
    try {
      firestore?.let { db ->
        val snapshot = db.collection("comments")
          .whereEqualTo("contentId", contentId)
          .orderBy("createdAt", Query.Direction.DESCENDING)
          .get().await()
        val list = snapshot.documents.mapNotNull { it.toObject(Comment::class.java) }
        if (list.isNotEmpty()) return@withContext list
      }
    } catch (e: Exception) {
      Log.w("CineNovaRepository", "Comments query: ${e.message}")
    }
    // Return sample seeded comments for that content
    listOf(
      Comment(
        commentId = "c1",
        userId = "u_cinenova_fan",
        userName = "Alex Mercer",
        contentId = contentId,
        text = "The cinematography and sound design in this are absolutely stellar!",
        createdAt = System.currentTimeMillis() - 86400000
      ),
      Comment(
        commentId = "c2",
        userId = "u_film_critic",
        userName = "Elena Rostova",
        contentId = contentId,
        text = "Loved the pacing. CineNova's streaming quality is so crisp on mobile!",
        createdAt = System.currentTimeMillis() - 36000000
      )
    )
  }

  suspend fun addComment(userId: String, userName: String, contentId: String, text: String): Result<Comment> =
    withContext(Dispatchers.IO) {
      if (text.isBlank()) return@withContext Result.failure(Exception("Comment cannot be empty"))
      val comment = Comment(
        commentId = "comm_${UUID.randomUUID().toString().take(10)}",
        userId = userId,
        userName = userName,
        contentId = contentId,
        text = text.trim(),
        createdAt = System.currentTimeMillis()
      )
      firestore?.collection("comments")?.document(comment.commentId)?.set(comment)
      Result.success(comment)
    }

  suspend fun deleteComment(commentId: String): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      firestore?.collection("comments")?.document(commentId)?.delete()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // Tasks and Coin transactions
  private val DAILY_COIN_LIMIT = 1000L

  suspend fun recordTaskProgress(userId: String, taskId: String, increment: Int) = withContext(Dispatchers.IO) {
    val dateKey = getTodayDateKey()
    val key = "${userId}_${taskId}_${dateKey}"
    val currentMap = _taskCompletions.value.toMutableMap()
    val existing = currentMap[key] ?: TaskCompletion(
      completionId = key,
      userId = userId,
      taskId = taskId,
      date = dateKey,
      completed = false,
      claimed = false,
      currentProgress = 0
    )

    if (existing.claimed) return@withContext // already claimed

    val task = _tasks.value.find { it.taskId == taskId } ?: return@withContext
    val newProgress = existing.currentProgress + increment
    val isCompleted = newProgress >= task.targetCount

    val updated = existing.copy(
      currentProgress = newProgress,
      completed = isCompleted
    )
    currentMap[key] = updated
    _taskCompletions.value = currentMap

    firestore?.collection("task_completions")?.document(key)?.set(updated)
  }

  suspend fun claimTaskReward(userId: String, taskId: String): Result<Int> = withContext(Dispatchers.IO) {
    val dateKey = getTodayDateKey()
    val key = "${userId}_${taskId}_${dateKey}"
    val task = _tasks.value.find { it.taskId == taskId }
      ?: return@withContext Result.failure(Exception("Task not found"))

    val completion = _taskCompletions.value[key]
    if (completion == null || !completion.completed) {
      return@withContext Result.failure(Exception("Task target not yet achieved"))
    }
    if (completion.claimed) {
      return@withContext Result.failure(Exception("Reward already claimed for today"))
    }

    val currentCoin = _coinBalance.value
    if (currentCoin.dailyEarned >= DAILY_COIN_LIMIT) {
      return@withContext Result.failure(Exception("Daily coin limit reached (Max $DAILY_COIN_LIMIT coins/day). Come back tomorrow!"))
    }

    val awardAmount = task.reward.coerceAtMost((DAILY_COIN_LIMIT - currentCoin.dailyEarned).toInt())
    if (awardAmount <= 0) {
      return@withContext Result.failure(Exception("Daily coin limit reached. Come back tomorrow!"))
    }

    val newBalance = currentCoin.balance + awardAmount
    val newDaily = currentCoin.dailyEarned + awardAmount
    val txnId = "TXN-${UUID.randomUUID().toString().take(8).uppercase()}"

    val transaction = CoinTransaction(
      transactionId = txnId,
      userId = userId,
      amount = awardAmount,
      reason = "Completed: ${task.title}",
      taskId = taskId,
      balanceAfter = newBalance,
      timestamp = System.currentTimeMillis()
    )

    // Save to prefs
    prefs.edit()
      .putLong("coin_balance_${userId}", newBalance)
      .putLong("coin_daily_${userId}_${dateKey}", newDaily)
      .apply()

    _coinBalance.value = CoinBalance(
      userId = userId,
      balance = newBalance,
      dailyEarned = newDaily,
      lastEarnedDate = dateKey
    )

    val updatedTxns = _coinTransactions.value.toMutableList()
    updatedTxns.add(0, transaction)
    _coinTransactions.value = updatedTxns

    // Update completion state
    val updatedCompletion = completion.copy(claimed = true, rewardTransactionId = txnId)
    val map = _taskCompletions.value.toMutableMap()
    map[key] = updatedCompletion
    _taskCompletions.value = map

    // Cloud sync
    firestore?.let { db ->
      db.collection("coins").document(userId).set(_coinBalance.value)
      db.collection("coin_transactions").document(txnId).set(transaction)
      db.collection("task_completions").document(key).set(updatedCompletion)
    }

    Result.success(awardAmount)
  }

  // Content uploaded by a specific user (shown on their Profile screen)
  fun myUploadedMovies(userId: String): List<Movie> =
    _movies.value.filter { it.uploaderId == userId }

  fun myUploadedShorts(userId: String): List<ShortVideo> =
    _shorts.value.filter { it.creatorId == userId }

  // -----------------------------------------------------------------------
  // Local upload outbox/cache
  // -----------------------------------------------------------------------
  // Firestore is the source of truth, but a local copy prevents an uploaded
  // video from disappearing from the app when the next startup happens while
  // Firestore is temporarily unavailable or a read is rejected by a rule.

  private fun mergeMovies(primary: List<Movie>, local: List<Movie>): List<Movie> {
    val byId = LinkedHashMap<String, Movie>()
    primary.forEach { if (it.movieId.isNotBlank()) byId[it.movieId] = it }
    local.forEach { if (it.movieId.isNotBlank()) byId.putIfAbsent(it.movieId, it) }
    return byId.values.toList()
  }

  private fun mergeShorts(primary: List<ShortVideo>, local: List<ShortVideo>): List<ShortVideo> {
    val byId = LinkedHashMap<String, ShortVideo>()
    primary.forEach { if (it.shortId.isNotBlank()) byId[it.shortId] = it }
    local.forEach { if (it.shortId.isNotBlank()) byId.putIfAbsent(it.shortId, it) }
    return byId.values.toList()
  }

  private fun loadLocalUploadedMovies(): List<Movie> {
    return runCatching {
      val array = JSONArray(prefs.getString(LOCAL_UPLOADED_MOVIES, "[]") ?: "[]")
      buildList {
        for (i in 0 until array.length()) {
          val o = array.optJSONObject(i) ?: continue
          add(
            Movie(
              movieId = o.optString("movieId"),
              title = o.optString("title"),
              description = o.optString("description"),
              poster = o.optString("poster"),
              backdrop = o.optString("backdrop"),
              videoUrl = o.optString("videoUrl"),
              category = o.optString("category", "Action"),
              tags = buildList {
                val tags = o.optJSONArray("tags")
                if (tags != null) for (j in 0 until tags.length()) add(tags.optString(j))
              },
              year = o.optInt("year", Calendar.getInstance().get(Calendar.YEAR)),
              duration = o.optString("duration", "HD Stream"),
              durationSeconds = o.optLong("durationSeconds", 600L),
              rating = o.optDouble("rating", 8.0),
              views = o.optLong("views", 0L),
              likes = o.optLong("likes", 0L),
              published = o.optBoolean("published", true),
              createdAt = o.optLong("createdAt", System.currentTimeMillis()),
              uploaderId = o.optString("uploaderId"),
              uploaderName = o.optString("uploaderName")
            )
          )
        }
      }.filter { it.movieId.isNotBlank() && it.videoUrl.isNotBlank() }
    }.getOrDefault(emptyList())
  }

  private fun loadLocalUploadedShorts(): List<ShortVideo> {
    return runCatching {
      val array = JSONArray(prefs.getString(LOCAL_UPLOADED_SHORTS, "[]") ?: "[]")
      buildList {
        for (i in 0 until array.length()) {
          val o = array.optJSONObject(i) ?: continue
          add(
            ShortVideo(
              shortId = o.optString("shortId"),
              title = o.optString("title"),
              description = o.optString("description"),
              videoUrl = o.optString("videoUrl"),
              thumbnail = o.optString("thumbnail"),
              creatorId = o.optString("creatorId"),
              creatorName = o.optString("creatorName", "CineNova Creator"),
              views = o.optLong("views", 0L),
              likes = o.optLong("likes", 0L),
              commentsCount = o.optLong("commentsCount", 0L),
              published = o.optBoolean("published", true),
              createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )
          )
        }
      }.filter { it.shortId.isNotBlank() && it.videoUrl.isNotBlank() }
    }.getOrDefault(emptyList())
  }

  private fun saveLocalUploadedMovies(movies: List<Movie>) {
    runCatching {
      val array = JSONArray()
      movies.take(50).forEach { movie ->
        array.put(
          JSONObject().apply {
            put("movieId", movie.movieId)
            put("title", movie.title)
            put("description", movie.description)
            put("poster", movie.poster)
            put("backdrop", movie.backdrop)
            put("videoUrl", movie.videoUrl)
            put("category", movie.category)
            put("tags", JSONArray(movie.tags))
            put("year", movie.year)
            put("duration", movie.duration)
            put("durationSeconds", movie.durationSeconds)
            put("rating", movie.rating)
            put("views", movie.views)
            put("likes", movie.likes)
            put("published", movie.published)
            put("createdAt", movie.createdAt)
            put("uploaderId", movie.uploaderId)
            put("uploaderName", movie.uploaderName)
          }
        )
      }
      prefs.edit().putString(LOCAL_UPLOADED_MOVIES, array.toString()).apply()
    }.onFailure { Log.w("CineNovaRepository", "Local movie cache save failed", it) }
  }

  private fun saveLocalUploadedShorts(shorts: List<ShortVideo>) {
    runCatching {
      val array = JSONArray()
      shorts.take(50).forEach { short ->
        array.put(
          JSONObject().apply {
            put("shortId", short.shortId)
            put("title", short.title)
            put("description", short.description)
            put("videoUrl", short.videoUrl)
            put("thumbnail", short.thumbnail)
            put("creatorId", short.creatorId)
            put("creatorName", short.creatorName)
            put("views", short.views)
            put("likes", short.likes)
            put("commentsCount", short.commentsCount)
            put("published", short.published)
            put("createdAt", short.createdAt)
          }
        )
      }
      prefs.edit().putString(LOCAL_UPLOADED_SHORTS, array.toString()).apply()
    }.onFailure { Log.w("CineNovaRepository", "Local short cache save failed", it) }
  }

  // Video Upload
  suspend fun uploadVideo(
    userId: String,
    userName: String = "Creator",
    title: String,
    description: String,
    category: String,
    tags: List<String>,
    isShort: Boolean,
    videoUri: Uri,
    posterUri: Uri?,
    onProgress: (Int) -> Unit
  ): Result<String> = withContext(Dispatchers.IO) {
    try {
      if (title.isBlank()) return@withContext Result.failure(Exception("Please enter a title"))

      // Video/poster files go to Supabase Storage (free, no billing card
      // required). Only the metadata (title, description, video URL, etc.)
      // is saved to Firestore, which stays free on the Spark plan.
      if (firestore == null) {
        return@withContext Result.failure(
          Exception("Upload is unavailable: Firestore is not configured for this app.")
        )
      }

      onProgress(15)
      var finalVideoUrl: String
      var finalPosterUrl = posterUri?.toString() ?: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&q=80"

      val storagePath = if (isShort) "videos/shorts/" else "videos/movies/"
      val detectedMime = context.contentResolver.getType(videoUri)
        ?.takeIf { it.startsWith("video/") }
        ?: "video/mp4"
      val extension = when {
        detectedMime.equals("video/x-matroska", ignoreCase = true) -> "mkv"
        detectedMime.equals("video/webm", ignoreCase = true) -> "webm"
        else -> "mp4"
      }
      val videoPath = "${storagePath}${UUID.randomUUID()}.$extension"

      onProgress(35)
      val uploadResult = SupabaseStorage.uploadFile(
        context = context,
        uri = videoUri,
        path = videoPath,
        mimeType = detectedMime
      )
      finalVideoUrl = uploadResult.getOrElse { e ->
        Log.e("CineNovaRepository", "Supabase video upload failed: ${e.message}")
        return@withContext Result.failure(Exception("Video upload failed: ${e.message}"))
      }

      if (!finalVideoUrl.startsWith("https://") && !finalVideoUrl.startsWith("http://")) {
        return@withContext Result.failure(Exception("Storage returned an invalid video URL."))
      }
      onProgress(85)

      if (posterUri != null) {
        val posterPath = "posters/${UUID.randomUUID()}.jpg"
        SupabaseStorage.uploadFile(
          context = context,
          uri = posterUri,
          path = posterPath,
          mimeType = "image/jpeg"
        ).onSuccess { url ->
          finalPosterUrl = url
        }.onFailure { e ->
          Log.w("CineNovaRepository", "Poster upload warning: ${e.message}")
        }
      }

      onProgress(90)
      val contentId = (if (isShort) "short_" else "mov_") + UUID.randomUUID().toString().take(8)

      if (isShort) {
        val newShort = ShortVideo(
          shortId = contentId,
          title = title,
          description = description,
          videoUrl = finalVideoUrl,
          thumbnail = finalPosterUrl,
          creatorId = userId,
          creatorName = userName,
          views = 0L,
          likes = 0L,
          commentsCount = 0L,
          published = true,
          createdAt = System.currentTimeMillis()
        )
        try {
          firestore.collection("shorts").document(contentId).set(newShort).await()
        } catch (e: Exception) {
          Log.e("CineNovaRepository", "Failed to save short to Firestore: ${e.message}")
          return@withContext Result.failure(Exception("Could not publish: ${e.message}"))
        }
        val currentList = _shorts.value.filterNot { it.shortId == newShort.shortId }.toMutableList()
        currentList.add(0, newShort)
        _shorts.value = currentList
        saveLocalUploadedShorts(currentList.filter { it.creatorId == userId && it.shortId.startsWith("short_") })
      } else {
        val newMovie = Movie(
          movieId = contentId,
          title = title,
          description = description,
          poster = finalPosterUrl,
          backdrop = finalPosterUrl,
          videoUrl = finalVideoUrl,
          category = category,
          tags = tags,
          year = Calendar.getInstance().get(Calendar.YEAR),
          duration = "HD Stream",
          durationSeconds = 600L,
          rating = 8.0,
          views = 0L,
          likes = 0L,
          published = true,
          createdAt = System.currentTimeMillis(),
          uploaderId = userId,
          uploaderName = userName
        )
        try {
          firestore.collection("movies").document(contentId).set(newMovie).await()
        } catch (e: Exception) {
          Log.e("CineNovaRepository", "Failed to save movie to Firestore: ${e.message}")
          return@withContext Result.failure(Exception("Could not publish: ${e.message}"))
        }
        val currentList = _movies.value.filterNot { it.movieId == newMovie.movieId }.toMutableList()
        currentList.add(0, newMovie)
        _movies.value = currentList
        saveLocalUploadedMovies(currentList.filter { it.uploaderId == userId && it.movieId.startsWith("mov_") })
      }

      onProgress(100)
      Result.success(contentId)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }
}
