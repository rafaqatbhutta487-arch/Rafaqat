package com.aistudio.cinenova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aistudio.cinenova.app.data.repository.AuthRepository
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.navigation.Screen
import com.aistudio.cinenova.app.ui.screens.*
import com.aistudio.cinenova.app.ui.theme.CineDarkBackground
import com.aistudio.cinenova.app.ui.theme.CineNovaTheme

class MainActivity : ComponentActivity() {

  private lateinit var authRepository: AuthRepository
  private lateinit var cineNovaRepository: CineNovaRepository

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    authRepository = AuthRepository(applicationContext)
    cineNovaRepository = CineNovaRepository(applicationContext)

    setContent {
      CineNovaTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = CineDarkBackground
        ) {
          CineNovaApp(
            authRepository = authRepository,
            repository = cineNovaRepository
          )
        }
      }
    }
  }
}

@Composable
fun CineNovaApp(
  authRepository: AuthRepository,
  repository: CineNovaRepository
) {
  val navController = rememberNavController()
  val currentUser by authRepository.currentUser.collectAsState()
  val userId = currentUser?.userId ?: "guest"
  val userName = currentUser?.name ?: "Streamer"

  NavHost(
    navController = navController,
    startDestination = Screen.Splash.route
  ) {
    // 1. Splash Screen
    composable(Screen.Splash.route) {
      SplashScreen(
        authRepository = authRepository,
        onNavigateToAuth = {
          navController.navigate(Screen.Auth.route) {
            popUpTo(Screen.Splash.route) { inclusive = true }
          }
        },
        onNavigateToHome = {
          navController.navigate(Screen.Main.route) {
            popUpTo(Screen.Splash.route) { inclusive = true }
          }
        }
      )
    }

    // 2. Authentication Screen
    composable(Screen.Auth.route) {
      AuthScreen(
        authRepository = authRepository,
        onAuthSuccess = {
          navController.navigate(Screen.Main.route) {
            popUpTo(Screen.Auth.route) { inclusive = true }
          }
        }
      )
    }

    // 3. Main Container Screen (5 Tabs: Home, Movies, Shorts, Tasks, Profile)
    composable(Screen.Main.route) {
      MainContainerScreen(
        authRepository = authRepository,
        repository = repository,
        onMovieClick = { movieId ->
          navController.navigate(Screen.MovieDetail.createRoute(movieId))
        },
        onPlayClick = { movieId ->
          navController.navigate(Screen.VideoPlayer.createRoute(movieId))
        },
        onPromoClick = {
          navController.navigate(Screen.PromotionPoster.route)
        },
        onSearchClick = {
          navController.navigate(Screen.Search.route)
        },
        onUploadClick = {
          navController.navigate(Screen.UploadVideo.route)
        },
        onWatchlistClick = {
          navController.navigate(Screen.Watchlist.route)
        },
        onWatchHistoryClick = {
          navController.navigate(Screen.WatchHistory.route)
        },
        onCoinHistoryClick = {
          navController.navigate(Screen.CoinHistory.route)
        },
        onSettingsClick = {
          navController.navigate(Screen.Settings.route)
        },
        onLogout = {
          navController.navigate(Screen.Auth.route) {
            popUpTo(0) { inclusive = true }
          }
        }
      )
    }

    // 4. Movie Detail Screen
    composable(
      route = Screen.MovieDetail.route,
      arguments = listOf(navArgument("movieId") { type = NavType.StringType })
    ) { backStackEntry ->
      val movieId = backStackEntry.arguments?.getString("movieId") ?: ""
      MovieDetailScreen(
        movieId = movieId,
        repository = repository,
        currentUserId = userId,
        currentUserName = userName,
        onBackClick = { navController.popBackStack() },
        onWatchClick = { id ->
          navController.navigate(Screen.VideoPlayer.createRoute(id))
        }
      )
    }

    // 5. Video Player Screen
    composable(
      route = Screen.VideoPlayer.route,
      arguments = listOf(navArgument("movieId") { type = NavType.StringType })
    ) { backStackEntry ->
      val movieId = backStackEntry.arguments?.getString("movieId") ?: ""
      VideoPlayerScreen(
        movieId = movieId,
        repository = repository,
        currentUserId = userId,
        onBackClick = { navController.popBackStack() }
      )
    }

    // 6. Promotion Poster Task Screen
    composable(Screen.PromotionPoster.route) {
      PromotionPosterScreen(
        repository = repository,
        currentUserId = userId,
        onBackClick = { navController.popBackStack() }
      )
    }

    // 7. Watchlist Screen
    composable(Screen.Watchlist.route) {
      WatchlistScreen(
        repository = repository,
        currentUserId = userId,
        onBackClick = { navController.popBackStack() },
        onMovieClick = { movieId ->
          navController.navigate(Screen.MovieDetail.createRoute(movieId))
        }
      )
    }

    // 8. Watch History Screen
    composable(Screen.WatchHistory.route) {
      WatchHistoryScreen(
        repository = repository,
        currentUserId = userId,
        onBackClick = { navController.popBackStack() },
        onPlayClick = { movieId ->
          navController.navigate(Screen.VideoPlayer.createRoute(movieId))
        }
      )
    }

    // 9. Coin History Screen
    composable(Screen.CoinHistory.route) {
      CoinHistoryScreen(
        repository = repository,
        currentUserId = userId,
        onBackClick = { navController.popBackStack() }
      )
    }

    // 10. Upload Video Screen
    composable(Screen.UploadVideo.route) {
      UploadVideoScreen(
        repository = repository,
        currentUserId = userId,
        currentUserName = userName,
        onBackClick = { navController.popBackStack() },
        onUploadSuccess = {
          navController.popBackStack()
        }
      )
    }

    // 11. Search Screen
    composable(Screen.Search.route) {
      SearchScreen(
        repository = repository,
        onBackClick = { navController.popBackStack() },
        onMovieClick = { movieId ->
          navController.navigate(Screen.MovieDetail.createRoute(movieId))
        },
        onShortsClick = {
          navController.navigate(Screen.Main.route)
        }
      )
    }

    // 12. Settings Screen
    composable(Screen.Settings.route) {
      SettingsScreen(
        authRepository = authRepository,
        onBackClick = { navController.popBackStack() }
      )
    }
  }
}
