package com.aistudio.cinenova.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.ui.theme.*

@Composable
fun ReportContentDialog(
  contentTitle: String,
  onDismiss: () -> Unit,
  onSubmitReport: (String) -> Unit
) {
  val reportReasons = listOf(
    "Copyright Infringement (DMCA)",
    "Inappropriate or Graphic Content",
    "Spam or Misleading Metadata",
    "Unauthorized Content",
    "Other Violation"
  )
  var selectedReason by remember { mutableStateOf(reportReasons[0]) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CineDarkSurface,
    title = {
      Text(
        text = "Report Content",
        color = CineTextPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Reporting: \"$contentTitle\"",
          color = CineTextSecondary,
          fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        reportReasons.forEach { reason ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .selectable(
                selected = (reason == selectedReason),
                onClick = { selectedReason = reason }
              )
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = (reason == selectedReason),
              onClick = { selectedReason = reason },
              colors = RadioButtonDefaults.colors(
                selectedColor = CineRed,
                unselectedColor = CineTextSecondary
              )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = reason,
              color = CineTextPrimary,
              fontSize = 13.sp
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onSubmitReport(selectedReason) },
        colors = ButtonDefaults.buttonColors(containerColor = CineRed),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text("Submit Report", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = CineTextSecondary)
      }
    }
  )
}
