package com.aistudio.cinenova.app.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.model.Comment
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.components.CommentBottomSheet
import com.aistudio.cinenova.app.ui.components.ReportContentDialog
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun MovieDetailScreen(
  movieId: String,
  repository: CineNovaRepository,
  currentUserId: String,
  currentUserName: String,
  onBackClick: () -> Unit,
  onWatchClick: (String) -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val movies by repository.movies.collectAsState()
  val watchlist by repository.watchlist.collectAsState()
  val userLikes by repository.userLikes.collectAsState()

  val movie = remember(movies, movieId) { movies.find { it.movieId == movieId } }

  var showCommentSheet by remember { mutableStateOf(false) }
  var showReportDialog by remember { mutableStateOf(false) }
  var commentsList by remember { mutableStateOf<List<Comment>>(emptyList()) }

  val isInWatchlist = remember(watchlist, movieId) { repository.isInWatchlist(movieId) }
  val isLiked = remember(userLikes, movieId) { repository.isContentLiked(movieId) }

  LaunchedEffect(movieId) {
    commentsList = repository.getComments(movieId)
  }

  if (movie == null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(CineDarkBackground),
      contentAlignment = Alignment.Center
    ) {
      Text("Movie not found", color = CineTextSecondary)
    }
    return
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .testTag("movie_detail_screen")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(bottom = 32.dp)
    ) {
      // Backdrop Hero Header with Back Button
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(300.dp)
      ) {
        AsyncImage(
          model = ImageRequest.Builder(context)
            .data(movie.backdrop.ifEmpty { movie.poster })
            .crossfade(true)
            .build(),
          contentDescription = movie.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Gradient
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  CineDarkBackground.copy(alpha = 0.6f),
                  Color.Transparent,
                  CineDarkBackground.copy(alpha = 0.8f),
                  CineDarkBackground
                )
              )
            )
        )

        // Back Button
        IconButton(
          onClick = onBackClick,
          modifier = Modifier
            .statusBarsPadding()
            .padding(12.dp)
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.6f))
            .testTag("movie_detail_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = Color.White
          )
        }

        // Play Button floating on hero
        Box(
          modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(CineRed)
            .align(Alignment.Center)
            .clickable { onWatchClick(movie.movieId) }
            .testTag("movie_detail_play_circle"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = "Play Video",
            tint = Color.White,
            modifier = Modifier.size(36.dp)
          )
        }
      }

      // Main Details Section
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        // Badges: Category, Year, Duration, Rating
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = CineRed
          ) {
            Text(
              text = movie.category,
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }

          Text(text = "${movie.year}", color = CineTextSecondary, fontSize = 13.sp)
          Text(text = "•", color = CineTextMuted, fontSize = 13.sp)
          Text(text = movie.duration, color = CineTextSecondary, fontSize = 13.sp)
          Text(text = "•", color = CineTextMuted, fontSize = 13.sp)

          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Icon(Icons.Default.Star, contentDescription = null, tint = CineGold, modifier = Modifier.size(14.dp))
            Text(
              text = String.format("%.1f", movie.rating),
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Title
        Text(
          text = movie.title,
          color = Color.White,
          fontWeight = FontWeight.Black,
          fontSize = 26.sp,
          lineHeight = 32.sp
        )

        // View and Likes counts
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          horizontalArrangement = Arrangement.spacedBy(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(Icons.Default.Visibility, contentDescription = null, tint = CineTextMuted, modifier = Modifier.size(14.dp))
            Text(text = "${movie.views} views", color = CineTextSecondary, fontSize = 12.sp)
          }
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(Icons.Default.Favorite, contentDescription = null, tint = CineRed, modifier = Modifier.size(14.dp))
            Text(text = "${movie.likes} likes", color = CineTextSecondary, fontSize = 12.sp)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Primary Watch Button
        Button(
          onClick = { onWatchClick(movie.movieId) },
          colors = ButtonDefaults.buttonColors(containerColor = CineRed),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("movie_watch_button")
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Watch Full Movie",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons Row: Watchlist, Like, Share, Comments, Report
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          // Watchlist Action
          ActionIconButton(
            icon = if (isInWatchlist) Icons.Default.Check else Icons.Default.Add,
            label = if (isInWatchlist) "Added" else "Watchlist",
            tint = if (isInWatchlist) CineGold else CineTextPrimary,
            onClick = {
              scope.launch {
                val added = repository.toggleWatchlist(currentUserId, movie)
                Toast.makeText(
                  context,
                  if (added) "Added to Watchlist" else "Removed from Watchlist",
                  Toast.LENGTH_SHORT
                ).show()
              }
            }
          )

          // Like Action
          ActionIconButton(
            icon = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            label = if (isLiked) "Liked" else "Like",
            tint = if (isLiked) CineRed else CineTextPrimary,
            onClick = {
              scope.launch {
                repository.toggleLike(currentUserId, movie.movieId, "movie")
              }
            }
          )

          // Comments Action
          ActionIconButton(
            icon = Icons.Default.Comment,
            label = "Comments",
            tint = CineTextPrimary,
            onClick = { showCommentSheet = true }
          )

          // Share Action
          ActionIconButton(
            icon = Icons.Default.Share,
            label = "Share",
            tint = CineTextPrimary,
            onClick = {
              val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(
                  Intent.EXTRA_TEXT,
                  "Watch \"${movie.title}\" on CineNova! Experience full cinematic streaming: ${movie.videoUrl}"
                )
                type = "text/plain"
              }
              context.startActivity(Intent.createChooser(shareIntent, "Share Movie"))
            }
          )

          // Report Content Action
          ActionIconButton(
            icon = Icons.Default.Flag,
            label = "Report",
            tint = CineTextMuted,
            onClick = { showReportDialog = true }
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Description
        Text(
          text = "Storyline",
          color = CineTextPrimary,
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = movie.description,
          color = CineTextSecondary,
          fontSize = 14.sp,
          lineHeight = 22.sp
        )

        // Tags
        if (movie.tags.isNotEmpty()) {
          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = "Tags",
            color = CineTextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            movie.tags.forEach { tag ->
              Surface(
                shape = RoundedCornerShape(16.dp),
                color = CineDarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, CineCardBorder)
              ) {
                Text(
                  text = "#$tag",
                  color = CineGoldLight,
                  fontSize = 12.sp,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
              }
            }
          }
        }
      }
    }
  }

  // Comments Bottom Sheet
  if (showCommentSheet) {
    CommentBottomSheet(
      comments = commentsList,
      currentUserId = currentUserId,
      onDismiss = { showCommentSheet = false },
      onAddComment = { text ->
        scope.launch {
          val res = repository.addComment(currentUserId, currentUserName, movieId, text)
          res.onSuccess {
            commentsList = listOf(it) + commentsList
          }
        }
      },
      onDeleteComment = { commentId ->
        scope.launch {
          repository.deleteComment(commentId)
          commentsList = commentsList.filterNot { it.commentId == commentId }
        }
      }
    )
  }

  // Report Content Dialog
  if (showReportDialog) {
    ReportContentDialog(
      contentTitle = movie.title,
      onDismiss = { showReportDialog = false },
      onSubmitReport = { reason ->
        showReportDialog = false
        Toast.makeText(
          context,
          "Thank you. Report received for review: $reason",
          Toast.LENGTH_LONG
        ).show()
      }
    )
  }
}

@Composable
private fun ActionIconButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  tint: Color,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .clickable { onClick() }
      .padding(8.dp)
  ) {
    Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
    Spacer(modifier = Modifier.height(4.dp))
    Text(text = label, color = CineTextSecondary, fontSize = 11.sp)
  }
}
