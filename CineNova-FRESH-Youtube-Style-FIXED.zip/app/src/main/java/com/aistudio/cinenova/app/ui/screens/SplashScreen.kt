package com.aistudio.cinenova.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.repository.AuthRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  authRepository: AuthRepository,
  onNavigateToAuth: () -> Unit,
  onNavigateToHome: () -> Unit
) {
  var startAnimation by remember { mutableStateOf(false) }
  val scaleAnim = animateFloatAsState(
    targetValue = if (startAnimation) 1f else 0.7f,
    animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
    label = "scale"
  )
  val alphaAnim = animateFloatAsState(
    targetValue = if (startAnimation) 1f else 0f,
    animationSpec = tween(durationMillis = 900),
    label = "alpha"
  )

  LaunchedEffect(Unit) {
    startAnimation = true
    delay(1600)
    if (authRepository.isAuthenticated) {
      onNavigateToHome()
    } else {
      onNavigateToAuth()
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.radialGradient(
          colors = listOf(Color(0xFF220C14), CineDarkBackground),
          radius = 1200f
        )
      )
      .testTag("splash_screen"),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier
        .scale(scaleAnim.value)
        .alpha(alphaAnim.value)
    ) {
      // CineNova Emblem
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(RoundedCornerShape(20.dp))
          .background(
            Brush.linearGradient(
              listOf(CineRed, Color(0xFF8B0000))
            )
          ),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "C",
          color = Color.White,
          fontWeight = FontWeight.Black,
          fontSize = 44.sp
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Text(
        text = "CineNova",
        color = Color.White,
        fontWeight = FontWeight.Black,
        fontSize = 32.sp,
        letterSpacing = 1.sp
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "Cinematic Streaming & Rewards",
        color = CineGoldLight,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp
      )
    }
  }
}
