package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*

@Composable
fun SearchScreen(
  repository: CineNovaRepository,
  onBackClick: () -> Unit,
  onMovieClick: (String) -> Unit,
  onShortsClick: () -> Unit
) {
  val context = LocalContext.current
  val movies by repository.movies.collectAsState()
  val shorts by repository.shorts.collectAsState()

  var query by remember { mutableStateOf("") }
  var filterType by remember { mutableStateOf("All") } // "All", "Movies", "Shorts"

  val matchingMovies = remember(query, movies, filterType) {
    if (filterType == "Shorts") emptyList()
    else if (query.isBlank()) emptyList()
    else movies.filter {
      it.title.contains(query, ignoreCase = true) ||
      it.description.contains(query, ignoreCase = true) ||
      it.category.contains(query, ignoreCase = true) ||
      it.tags.any { tag -> tag.contains(query, ignoreCase = true) }
    }
  }

  val matchingShorts = remember(query, shorts, filterType) {
    if (filterType == "Movies") emptyList()
    else if (query.isBlank()) emptyList()
    else shorts.filter {
      it.title.contains(query, ignoreCase = true) ||
      it.description.contains(query, ignoreCase = true) ||
      it.creatorName.contains(query, ignoreCase = true)
    }
  }

  val totalResults = matchingMovies.size + matchingShorts.size

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .statusBarsPadding()
      .testTag("search_screen")
  ) {
    // Search Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClick) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
      }

      OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        placeholder = { Text("Search movies, genres, tags...", color = CineTextMuted, fontSize = 14.sp) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CineGold) },
        trailingIcon = {
          if (query.isNotEmpty()) {
            IconButton(onClick = { query = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "Clear", tint = CineTextSecondary)
            }
          }
        },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CineRed,
          unfocusedBorderColor = CineCardBorder,
          focusedTextColor = CineTextPrimary,
          unfocusedTextColor = CineTextPrimary,
          focusedContainerColor = CineDarkSurface,
          unfocusedContainerColor = CineDarkSurface
        ),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
          .weight(1f)
          .testTag("search_query_input")
      )
    }

    // Filter Type Pills (All, Movies, Shorts)
    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      val types = listOf("All", "Movies", "Shorts")
      items(types) { type ->
        val isSelected = type == filterType
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = if (isSelected) CineRed else CineDarkSurface,
          border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) CineRed else CineCardBorder),
          modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { filterType = type }
        ) {
          Text(
            text = type,
            color = if (isSelected) Color.White else CineTextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
          )
        }
      }
    }

    // Content Results
    if (query.isBlank()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Search, contentDescription = null, tint = CineTextMuted, modifier = Modifier.size(48.dp))
          Text(
            text = "Discover CineNova Movies & Shorts",
            color = CineTextSecondary,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
          Text(
            text = "Search across thousands of cinematic titles, genres, and creator videos.",
            color = CineTextMuted,
            fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
          )
        }
      }
    } else if (totalResults == 0) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No results found matching \"$query\".\nTry searching for \"Action\", \"Interstellar\", or \"Sci-Fi\".",
          color = CineTextMuted,
          fontSize = 14.sp,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center,
          lineHeight = 22.sp
        )
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        if (matchingMovies.isNotEmpty()) {
          item {
            Text(
              text = "Movies (${matchingMovies.size})",
              color = CineGoldLight,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              modifier = Modifier.padding(vertical = 4.dp)
            )
          }

          items(matchingMovies, key = { it.movieId }) { movie ->
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onMovieClick(movie.movieId) }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
              ) {
                AsyncImage(
                  model = ImageRequest.Builder(context)
                    .data(movie.poster)
                    .crossfade(true)
                    .build(),
                  contentDescription = movie.title,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier
                    .width(64.dp)
                    .height(86.dp)
                    .clip(RoundedCornerShape(8.dp))
                )

                Column(modifier = Modifier.weight(1f)) {
                  Text(text = movie.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text(text = "${movie.category} • ${movie.year} • ${movie.duration}", color = CineTextSecondary, fontSize = 11.sp)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(text = movie.description, color = CineTextMuted, fontSize = 11.sp, maxLines = 2)
                }

                Icon(Icons.Default.PlayArrow, contentDescription = "Watch", tint = CineRed)
              }
            }
          }
        }

        if (matchingShorts.isNotEmpty()) {
          item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "CineShorts (${matchingShorts.size})",
              color = CineGoldLight,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              modifier = Modifier.padding(vertical = 4.dp)
            )
          }

          items(matchingShorts, key = { it.shortId }) { short ->
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onShortsClick() }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
              ) {
                AsyncImage(
                  model = short.thumbnail,
                  contentDescription = short.title,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier
                    .width(64.dp)
                    .height(86.dp)
                    .clip(RoundedCornerShape(8.dp))
                )

                Column(modifier = Modifier.weight(1f)) {
                  Text(text = short.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text(text = "@${short.creatorName} • ${short.views} views", color = CineTextSecondary, fontSize = 11.sp)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(text = short.description, color = CineTextMuted, fontSize = 11.sp, maxLines = 2)
                }

                Icon(Icons.Default.PlayArrow, contentDescription = "Watch", tint = CineGold)
              }
            }
          }
        }
      }
    }
  }
}
