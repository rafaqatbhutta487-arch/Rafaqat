package com.aistudio.cinenova.app

import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.dp
import com.aistudio.cinenova.app.data.model.Movie
import com.aistudio.cinenova.app.ui.components.MovieCard
import com.aistudio.cinenova.app.ui.theme.CineNovaTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun cinenova_movie_card_screenshot() {
    val sampleMovie = Movie(
      movieId = "test_mov_1",
      title = "CineNova Premiere",
      category = "Sci-Fi",
      year = 2024,
      rating = 9.2
    )

    composeTestRule.setContent {
      CineNovaTheme {
        MovieCard(
          movie = sampleMovie,
          onClick = {},
          modifier = Modifier.padding(16.dp)
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/cinenova_movie_card.png")
  }
}
