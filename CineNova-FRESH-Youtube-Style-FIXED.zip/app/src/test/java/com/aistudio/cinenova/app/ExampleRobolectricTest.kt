package com.aistudio.cinenova.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.aistudio.cinenova.app.data.repository.AuthRepository
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("CineNova", appName)
  }

  @Test
  fun `repository loads initial movie catalog`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = CineNovaRepository(context)

    val movies = repository.movies.first()
    assertTrue("Movies catalog should not be empty", movies.isNotEmpty())
    val firstMovie = movies.first()
    assertNotNull(firstMovie.title)
    assertTrue("Movie duration should be positive", firstMovie.durationSeconds > 0)
  }

  @Test
  fun `repository loads initial shorts catalog`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = CineNovaRepository(context)

    val shorts = repository.shorts.first()
    assertTrue("Shorts catalog should not be empty", shorts.isNotEmpty())
    val firstShort = shorts.first()
    assertNotNull(firstShort.creatorName)
  }

  @Test
  fun `watchlist toggle adds and removes content`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = CineNovaRepository(context)
    val testUserId = "test_user_cuj"
    val testMovie = repository.movies.first().first()

    assertFalse(repository.isInWatchlist(testMovie.movieId))

    repository.toggleWatchlist(testUserId, testMovie)
    assertTrue(repository.isInWatchlist(testMovie.movieId))

    repository.toggleWatchlist(testUserId, testMovie)
    assertFalse(repository.isInWatchlist(testMovie.movieId))
  }

  @Test
  fun `like toggle updates state properly`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = CineNovaRepository(context)
    val testUserId = "test_user_cuj"
    val testMovieId = "mov_tears_of_steel"

    val initialLiked = repository.isContentLiked(testMovieId)
    repository.toggleLike(testUserId, testMovieId, "movie")
    assertEquals(!initialLiked, repository.isContentLiked(testMovieId))
  }

  @Test
  fun `daily tasks list is populated and valid`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = CineNovaRepository(context)

    val tasks = repository.tasks.first()
    assertTrue("Tasks should be populated", tasks.isNotEmpty())
    assertTrue("Tasks should contain rewards", tasks.all { task -> task.reward > 0 })
  }

  @Test
  fun `auth repository guest login and session persistence`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val authRepo = AuthRepository(context)

    val user = authRepo.signInAsGuest()
    assertNotNull(user)
    assertEquals(user.userId, authRepo.currentUser.value?.userId)

    // Verify profile update
    authRepo.updateProfile("CineNova Pro Member")
    assertEquals("CineNova Pro Member", authRepo.currentUser.value?.name)

    // Verify logout
    authRepo.logout()
    assertNull(authRepo.currentUser.value)
  }
}
