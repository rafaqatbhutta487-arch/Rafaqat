CineNova APK build notes

This project is prepared for GitHub Actions APK builds.

Required project files include:
- gradlew
- gradlew.bat
- gradle/wrapper/gradle-wrapper.properties
- app/
- build.gradle.kts
- settings.gradle.kts

The gradlew script downloads Gradle 9.3.1 on first run, so the Gradle wrapper JAR is not required.

For GitHub Actions, the build command is:
  chmod +x ./gradlew
  ./gradlew assembleDebug

The debug APK is produced under:
  app/build/outputs/apk/debug/
