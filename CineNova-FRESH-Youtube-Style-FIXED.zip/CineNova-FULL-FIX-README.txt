CineNova FULL FIX - 2026-09-19

This project was repaired from the supplied CineNova APK-ready source ZIP.

Main fixes:
1. Video playback no longer writes watch progress to Firestore on every 500ms position update.
2. Watch progress is saved about every 10 seconds and on pause/end.
3. ExoPlayer lifecycle is safer: one player per screen, URL validation, guarded controls, retry, and release/close handling.
4. Invalid/empty video URLs show an in-app error instead of taking down playback.
5. Large video uploads are streamed from ContentResolver instead of readBytes(), avoiding loading the whole video into RAM.
6. The real selected video MIME type is used for Supabase upload; MP4/MKV/WebM paths are handled.
7. Uploaded movie/short metadata is cached locally so an uploaded item does not disappear when Firestore is temporarily unavailable on app restart.
8. Remote Firestore content is merged with the local uploaded cache instead of replacing it blindly.
9. Google Sign-In now uses the OAuth web client ID from google-services.json instead of the placeholder client ID.
10. compileSdk is normalized to 36 to avoid requiring the 36.1 extension on the build runner.
11. Gradle configuration cache is disabled for a more conservative CI build.
12. Unused KSP/Room/codegen build dependencies were removed because the supplied source contains no Room/KSP/Moshi-codegen usage.

Important external setup:
- Google Sign-In can still require the Android app SHA-1/SHA-256 fingerprints to be registered in Firebase/Google Cloud.
- Supabase bucket/policies must allow the app's intended upload/read access.
- The supplied Supabase key and project URL were preserved from the original project.

Build target:
./gradlew clean :app:assembleDebug
