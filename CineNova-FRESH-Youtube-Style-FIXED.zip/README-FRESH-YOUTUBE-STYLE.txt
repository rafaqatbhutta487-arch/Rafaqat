
CineNova Fresh Feed Update
==========================
- Removed seeded/demo movies and shorts.
- Firestore no longer receives automatic demo content.
- Home starts empty and shows a clean "No videos yet" state.
- Only published user uploads from Firestore and the local upload cache are shown.
- Added extra playback/data/history/content settings while preserving the existing CineNova design.
- Existing upload, player, auth, comments, likes, watchlist and settings architecture is preserved.
