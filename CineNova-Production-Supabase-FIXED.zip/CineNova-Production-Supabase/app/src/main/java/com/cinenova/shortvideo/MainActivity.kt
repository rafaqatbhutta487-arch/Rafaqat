package com.cinenova.shortvideo

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.cinenova.shortvideo.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF151B2E)
private val Accent = Color(0xFF6EE7F9)
private val Accent2 = Color(0xFF9B8CFF)

class MainActivity : ComponentActivity() {
    private lateinit var client: SupabaseClient
    private var authUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        client = SupabaseClient(applicationContext)
        authUri = intent?.data
        setContent { CineNovaTheme { CineNovaRoot(client, authUri) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        authUri = intent.data
    }
}

class CineNovaViewModel(private val client: SupabaseClient) : ViewModel() {
    var session by mutableStateOf(client.currentSession())
        private set
    var profile by mutableStateOf<Profile?>(null)
        private set
    var feed by mutableStateOf<List<Video>>(emptyList())
        private set
    var myVideos by mutableStateOf<List<Video>>(emptyList())
        private set
    var notifications by mutableStateOf<List<NotificationItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var toast by mutableStateOf<String?>(null)
        private set
    var uploadProgress by mutableFloatStateOf(0f)
        private set

    private var loadJob: Job? = null

    init {
        if (session != null) loadUser()
    }

    fun clearMessage() { error = null; toast = null }

    fun signIn(email: String, password: String, done: () -> Unit) = viewModelScope.launch {
        loading = true
        error = null
        client.signIn(email, password)
            .onSuccess { session = it; loadUser(); done() }
            .onFailure { error = it.message }
        loading = false
    }

    fun signUp(email: String, password: String) = viewModelScope.launch {
        loading = true
        error = null
        client.signUp(email, password)
            .onSuccess { toast = it }
            .onFailure { error = it.message }
        loading = false
    }

    fun reset(email: String) = viewModelScope.launch {
        loading = true
        client.resetPassword(email)
            .onSuccess { toast = it }
            .onFailure { error = it.message }
        loading = false
    }

    fun startGoogle(context: android.content.Context) {
        val pkce = client.beginGooglePkce()
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(pkce.url)))
    }

    fun finishOAuth(uri: Uri, done: () -> Unit) = viewModelScope.launch {
        val code = uri.getQueryParameter("code")
        val state = uri.getQueryParameter("state")
        if (code.isNullOrBlank() || state.isNullOrBlank()) {
            error = "Google sign-in did not return a valid authorization code."
            return@launch
        }
        loading = true
        client.finishGooglePkce(code, state)
            .onSuccess { session = it; loadUser(); done() }
            .onFailure { error = it.message }
        loading = false
    }

    fun logout() {
        client.signOut()
        session = null
        profile = null
        feed = emptyList()
        myVideos = emptyList()
        notifications = emptyList()
    }

    fun loadUser() {
        val s = session ?: return
        viewModelScope.launch {
            profile = client.getProfile(s.userId)
            if (profile == null) {
                client.upsertProfile(Profile(s.userId, "user_${s.userId.take(8)}", s.email?.substringBefore('@') ?: "CineNova User", "", ""))
                profile = client.getProfile(s.userId)
            }
            refreshFeed()
            myVideos = client.myVideos(s.userId)
            notifications = client.notifications()
        }
    }

    fun refreshFeed() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            loading = true
            feed = client.publishedVideos()
            loading = false
        }
    }

    fun search(q: String, onResult: (List<Video>) -> Unit) = viewModelScope.launch {
        onResult(client.searchVideos(q))
    }

    fun searchProfiles(q: String, onResult: (List<Profile>) -> Unit) = viewModelScope.launch {
        onResult(client.searchProfiles(q))
    }

    fun recordView(videoId: String) = viewModelScope.launch { client.recordView(videoId) }

    fun like(videoId: String) = viewModelScope.launch {
        client.toggleLike(videoId)
            .onSuccess { liked ->
                feed = feed.map {
                    if (it.id == videoId) it.copy(likesCount = (it.likesCount + if (liked) 1 else -1).coerceAtLeast(0)) else it
                }
            }
            .onFailure { error = it.message }
    }

    fun save(videoId: String) = viewModelScope.launch {
        client.saveVideo(videoId).onSuccess { toast = if (it) "Saved" else "Removed from saved" }.onFailure { error = it.message }
    }

    fun follow(userId: String) = viewModelScope.launch {
        client.follow(userId).onSuccess { toast = if (it) "Following" else "Unfollowed" }.onFailure { error = it.message }
    }

    fun comment(videoId: String, text: String, done: () -> Unit) = viewModelScope.launch {
        client.addComment(videoId, text).onSuccess { toast = "Comment posted"; done() }.onFailure { error = it.message }
    }

    fun upload(uri: Uri, title: String, description: String, hashtags: List<String>, done: () -> Unit) = viewModelScope.launch {
        loading = true
        uploadProgress = 0f
        error = null
        client.uploadVideo(uri, title, description, hashtags) { sent, total ->
            uploadProgress = if (total > 0) sent.toFloat() / total else 0f
        }.onSuccess {
            toast = "Video published"
            session?.userId?.let { myVideos = client.myVideos(it) }
            refreshFeed()
            done()
        }.onFailure { error = it.message }
        loading = false
        uploadProgress = 0f
    }

    fun updateProfile(name: String, username: String, bio: String, done: () -> Unit) = viewModelScope.launch {
        client.updateProfile(name, username, bio, profile?.avatarUrl.orEmpty())
            .onSuccess { session?.userId?.let { profile = client.getProfile(it) }; toast = "Profile updated"; done() }
            .onFailure { error = it.message }
    }

    fun deleteVideo(id: String) = viewModelScope.launch {
        client.deleteOwnVideo(id).onSuccess {
            toast = "Video deleted"
            session?.userId?.let { myVideos = client.myVideos(it) }
            refreshFeed()
        }.onFailure { error = it.message }
    }

    fun report(id: String, reason: String) = viewModelScope.launch {
        client.reportVideo(id, reason).onSuccess { toast = "Report submitted" }.onFailure { error = it.message }
    }

    suspend fun loadComments(id: String) = client.comments(id)

    fun markRead() = viewModelScope.launch {
        client.markNotificationsRead()
        notifications = client.notifications()
    }
}

@Composable
fun CineNovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Accent2,
            background = Ink,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun CineNovaRoot(client: SupabaseClient, deepLink: Uri?, vm: CineNovaViewModel = viewModel { CineNovaViewModel(client) }) {
    var authenticated by remember { mutableStateOf(vm.session != null) }
    LaunchedEffect(deepLink) {
        if (deepLink?.scheme == "cinenova" && deepLink.host == "auth") {
            vm.finishOAuth(deepLink) { authenticated = true }
        }
    }
    LaunchedEffect(vm.session) { authenticated = vm.session != null }

    if (!authenticated) AuthScreen(vm) { authenticated = true } else MainShell(vm)

    vm.error?.let { msg ->
        AlertDialog(
            onDismissRequest = vm::clearMessage,
            confirmButton = { TextButton(onClick = vm::clearMessage) { Text("OK") } },
            title = { Text("CineNova") },
            text = { Text(msg) }
        )
    }
}

@Composable
fun AuthScreen(vm: CineNovaViewModel, onSuccess: () -> Unit) {
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(Ink).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("CineNova", fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, color = Accent)
        Text("Real short videos. Real creators.", color = Color.LightGray, modifier = Modifier.padding(top = 6.dp, bottom = 30.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
        Button(
            onClick = { if (register) vm.signUp(email, pass) else vm.signIn(email, pass, onSuccess) },
            enabled = !vm.loading && email.isNotBlank() && pass.length >= 6,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) { Text(if (register) "Create account" else "Sign in") }
        OutlinedButton(onClick = { vm.startGoogle(ctx) }, enabled = !vm.loading, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Continue with Google") }
        TextButton(onClick = { register = !register }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text(if (register) "Already have an account? Sign in" else "Create a new account")
        }
        if (!register) TextButton(onClick = { vm.reset(email) }) { Text("Forgot password?") }
        if (vm.loading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
    }
}

@Composable
fun MainShell(vm: CineNovaViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Ink,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                val labels = listOf("Home", "Discover", "Create", "Inbox", "Profile")
                val icons = listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.AddBox, Icons.Default.Notifications, Icons.Default.Person)
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> FeedScreen(vm)
                1 -> DiscoverScreen(vm)
                2 -> CreateScreen(vm)
                3 -> InboxScreen(vm)
                4 -> ProfileScreen(vm)
            }
        }
    }
}

@Composable
fun FeedScreen(vm: CineNovaViewModel) {
    LaunchedEffect(Unit) { vm.refreshFeed() }
    val pager = rememberPagerState(pageCount = { vm.feed.size.coerceAtLeast(1) })
    var commentsFor by remember { mutableStateOf<Video?>(null) }
    Box(Modifier.fillMaxSize()) {
        if (vm.feed.isEmpty()) {
            EmptyState("No published videos yet", "Be the first real creator. Tap Create to upload a video.", Modifier.fillMaxSize())
        } else {
            VerticalPager(state = pager, beyondViewportPageCount = 0, modifier = Modifier.fillMaxSize()) { page ->
                val video = vm.feed[page]
                VideoPage(video, vm, { vm.like(video.id) }, { commentsFor = video }, { vm.save(video.id) }, { vm.follow(video.userId) }, { vm.report(video.id, "User report") })
            }
        }
        if (vm.loading) LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth())
    }
    commentsFor?.let { CommentsSheet(it, vm) { commentsFor = null } }
}

@Composable
fun VideoPage(video: Video, vm: CineNovaViewModel, onLike: () -> Unit, onComments: () -> Unit, onSave: () -> Unit, onFollow: () -> Unit, onReport: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(video.id) { vm.recordView(video.id) }
    val player = remember(video.videoUrl) {
        ExoPlayer.Builder(ctx).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            setMediaItem(MediaItem.fromUri(video.videoUrl))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { useController = false; this.player = player } }, modifier = Modifier.fillMaxSize())
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(model = video.avatarUrl, contentDescription = null, modifier = Modifier.size(42.dp).clip(CircleShape))
                Column(Modifier.padding(start = 10.dp).weight(1f)) {
                    Text("@${video.username.ifBlank { "creator" }}", fontWeight = FontWeight.Bold)
                    Text(video.title, maxLines = 1)
                }
                TextButton(onClick = onFollow) { Text("Follow") }
            }
            Text(video.description, maxLines = 3, modifier = Modifier.padding(top = 6.dp))
            if (video.hashtags.isNotEmpty()) Text(video.hashtags.joinToString(" ") { "#$it" }, color = Accent, modifier = Modifier.padding(top = 4.dp))
        }
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = onLike) { Icon(Icons.Default.Favorite, null, tint = Color.White) }
            Text("${video.likesCount}")
            IconButton(onClick = onComments) { Icon(Icons.Default.Comment, null, tint = Color.White) }
            Text("${video.commentsCount}")
            IconButton(onClick = onSave) { Icon(Icons.Default.Bookmark, null, tint = Color.White) }
            IconButton(onClick = { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, video.videoUrl) }, "Share video")) }) { Icon(Icons.Default.Share, null, tint = Color.White) }
            IconButton(onClick = onReport) { Icon(Icons.Default.Flag, null, tint = Color.White) }
        }
    }
}

@Composable
fun CommentsSheet(video: Video, vm: CineNovaViewModel, onClose: () -> Unit) {
    var comments by remember { mutableStateOf<List<CommentItem>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    LaunchedEffect(video.id) { comments = vm.loadComments(video.id) }
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Comments", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(comments) { c ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                        AsyncImage(model = c.avatarUrl, contentDescription = null, modifier = Modifier.size(34.dp).clip(CircleShape))
                        Column(Modifier.padding(start = 8.dp)) { Text(c.username, fontWeight = FontWeight.Bold); Text(c.text) }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Add a comment") })
                IconButton(onClick = { if (text.isNotBlank()) vm.comment(video.id, text) { text = ""; comments = vm.loadComments(video.id) } }) { Icon(Icons.Default.Send, null) }
            }
        }
    }
}

@Composable
fun DiscoverScreen(vm: CineNovaViewModel) {
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Video>>(emptyList()) }
    var people by remember { mutableStateOf<List<Profile>>(emptyList()) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(q, { q = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search videos or creators") }, trailingIcon = {
            IconButton(onClick = { vm.search(q) { results = it }; vm.searchProfiles(q) { people = it } }) { Icon(Icons.Default.Search, null) }
        })
        Spacer(Modifier.height(12.dp))
        Text("Creators", fontWeight = FontWeight.Bold)
        if (people.isEmpty()) Text("No creator matches", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
        else LazyColumn(Modifier.heightIn(max = 180.dp)) { items(people) { p ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                AsyncImage(model = p.avatarUrl, contentDescription = null, modifier = Modifier.size(40.dp).clip(CircleShape))
                Column(Modifier.padding(start = 8.dp)) { Text(p.displayName); Text("@${p.username}", color = Accent) }
            }
        } }
        Text("Videos", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        if (results.isEmpty()) Text("No video matches", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
        else LazyColumn { items(results) { SearchVideoRow(it) } }
    }
}

@Composable
fun SearchVideoRow(v: Video) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(10.dp)) {
        AsyncImage(model = v.thumbnailUrl, contentDescription = null, modifier = Modifier.size(90.dp, 120.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
        Column(Modifier.padding(start = 10.dp)) {
            Text(v.title, fontWeight = FontWeight.Bold)
            Text(v.description, maxLines = 3, color = Color.LightGray)
            Text("${v.viewsCount} views • ${v.likesCount} likes", color = Accent)
        }
    }
}

@Composable
fun CreateScreen(vm: CineNovaViewModel) {
    var selected by remember { mutableStateOf<Uri?>(null) }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { selected = it }
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Create", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Publish only your real video content.", color = Color.LightGray, modifier = Modifier.padding(bottom = 14.dp))
        Button(onClick = { picker.launch("video/*") }) { Text(if (selected == null) "Choose video" else "Video selected ✓") }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(desc, { desc = it }, label = { Text("Caption") }, modifier = Modifier.fillMaxWidth().height(110.dp))
        OutlinedTextField(tags, { tags = it }, label = { Text("Hashtags (space separated)") }, modifier = Modifier.fillMaxWidth())
        if (vm.loading) {
            LinearProgressIndicator(progress = { vm.uploadProgress }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
            Text("Uploading ${(vm.uploadProgress * 100).toInt()}%", color = Accent)
        }
        Button(
            onClick = {
                selected?.let { uri ->
                    vm.upload(uri, title, desc, tags.split(" ").map { it.trim().removePrefix("#") }.filter { it.isNotBlank() }) {
                        selected = null; title = ""; desc = ""; tags = ""
                    }
                }
            },
            enabled = selected != null && !vm.loading && title.isNotBlank(),
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) { Text("Publish") }
        Text("Record with the phone camera and select the recorded file here. No temporary blob URL is stored.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
fun InboxScreen(vm: CineNovaViewModel) {
    LaunchedEffect(Unit) { vm.markRead() }
    if (vm.notifications.isEmpty()) EmptyState("Inbox is empty", "Real likes, comments, follows and mentions will appear here.", Modifier.fillMaxSize())
    else LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        items(vm.notifications) { n ->
            ListItem(headlineContent = { Text(n.actorName.ifBlank { "CineNova user" }) }, supportingContent = { Text(n.message) }, leadingContent = { AsyncImage(model = n.actorAvatar, contentDescription = null, modifier = Modifier.size(42.dp).clip(CircleShape)) }, colors = ListItemDefaults.colors(containerColor = Color.Transparent))
        }
    }
}

@Composable
fun ProfileScreen(vm: CineNovaViewModel) {
    val p = vm.profile
    var edit by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = p?.avatarUrl, contentDescription = null, modifier = Modifier.size(76.dp).clip(CircleShape))
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(p?.displayName?.ifBlank { "CineNova User" } ?: "CineNova User", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("@${p?.username ?: "user"}", color = Accent)
                Text(p?.bio.orEmpty(), color = Color.LightGray, maxLines = 3)
            }
            IconButton(onClick = { edit = true }) { Icon(Icons.Default.Edit, null) }
            IconButton(onClick = { settings = true }) { Icon(Icons.Default.Settings, null) }
        }
        Spacer(Modifier.height(14.dp))
        Text("Your videos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (vm.myVideos.isEmpty()) Text("You have not published a video yet.", color = Color.Gray, modifier = Modifier.padding(top = 12.dp))
        else LazyColumn {
            items(vm.myVideos) { v ->
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(12.dp)).padding(10.dp)) {
                    Column(Modifier.weight(1f)) { Text(v.title, fontWeight = FontWeight.Bold); Text("${v.viewsCount} views • ${v.likesCount} likes", color = Color.LightGray) }
                    IconButton(onClick = { vm.deleteVideo(v.id) }) { Icon(Icons.Default.Delete, null) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = vm::logout) { Text("Logout") }
    }
    if (edit) EditProfileDialog(p, vm) { edit = false }
    if (settings) SettingsDialog(vm) { settings = false }
}

@Composable
fun EditProfileDialog(p: Profile?, vm: CineNovaViewModel, onClose: () -> Unit) {
    var name by remember { mutableStateOf(p?.displayName.orEmpty()) }
    var user by remember { mutableStateOf(p?.username.orEmpty()) }
    var bio by remember { mutableStateOf(p?.bio.orEmpty()) }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { Button(onClick = { vm.updateProfile(name, user, bio, onClose) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
        title = { Text("Edit profile") },
        text = { Column { OutlinedTextField(name, { name = it }, label = { Text("Display name") }); OutlinedTextField(user, { user = it }, label = { Text("Username") }); OutlinedTextField(bio, { bio = it }, label = { Text("Bio") }) } }
    )
}

@Composable
fun SettingsDialog(vm: CineNovaViewModel, onClose: () -> Unit) {
    var privateAccount by remember { mutableStateOf(false) }
    var autoplay by remember { mutableStateOf(true) }
    var dataSaver by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } },
        title = { Text("Settings") },
        text = {
            Column {
                Text("Privacy", fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Private account", Modifier.weight(1f)); Switch(privateAccount, { privateAccount = it }) }
                Text("Playback", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Autoplay", Modifier.weight(1f)); Switch(autoplay, { autoplay = it }) }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Data saver", Modifier.weight(1f)); Switch(dataSaver, { dataSaver = it }) }
                Text("Security", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                TextButton(onClick = { vm.logout(); onClose() }) { Text("Logout") }
                Text("Account deletion must be handled by a protected Supabase Edge Function; no admin key is embedded in the APK.", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                Text("CineNova 1.0.0", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 10.dp))
            }
        }
    )
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier) {
    Column(modifier.padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.PlayCircleOutline, null, tint = Accent, modifier = Modifier.size(72.dp))
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(body, color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
    }
}
